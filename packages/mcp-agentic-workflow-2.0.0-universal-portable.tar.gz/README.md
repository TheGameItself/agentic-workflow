# MCP Agentic Workflow Accelerator - Universal Portable

This is a universal portable version that works on any platform with Python 3.8+.

## Quick Start

1. Extract this package to any location
2. Run the launcher for your platform:
   - **Windows**: `start_mcp.bat` or `start_mcp.ps1`
   - **macOS/Linux**: `./start_mcp.sh`

## Requirements

- Python 3.8 or later
- Internet connection for first run (to install dependencies)

## Features

- **Universal**: Works on any platform with Python
- **Self-contained**: All source code included
- **Portable**: No installation required
- **Cross-platform**: Windows, macOS, and Linux support

## Manual Installation

If the launchers don't work, you can run manually:

```bash
python3 mcp_cli.py
```

## Dependencies

The application will automatically install required dependencies on first run.
