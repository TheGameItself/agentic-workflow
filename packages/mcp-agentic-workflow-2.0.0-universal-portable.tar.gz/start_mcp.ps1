# PowerShell launcher for MCP Agentic Workflow Accelerator
Write-Host "Starting MCP Agentic Workflow Accelerator..." -ForegroundColor Green
Set-Location $PSScriptRoot
python mcp_cli.py
