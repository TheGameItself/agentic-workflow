#!/usr/bin/env python3
"""
Example Plugin for MCP Server
"""

from .plugin import ExamplePlugin

__all__ = ["ExamplePlugin"] 