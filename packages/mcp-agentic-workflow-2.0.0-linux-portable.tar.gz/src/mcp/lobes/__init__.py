"""
Lobes package for the MCP server.

This package contains all the experimental lobes organized by functionality.
Each lobe represents a specialized cognitive function inspired by brain research.
"""

from .alignment_engine import AlignmentEngine
from .pattern_recognition_engine import PatternRecognitionEngine
from ..experimental_lobes import (
    SimulatedReality,
    DreamingEngine,
    MindMapEngine,
    ScientificProcessEngine,
    SpeculationEngine,
    SplitBrainABTest,
    MultiLLMOrchestrator,
    AdvancedEngramEngine
)

__all__ = [
    'AlignmentEngine',
    'PatternRecognitionEngine', 
    'SimulatedReality',
    'DreamingEngine',
    'MindMapEngine',
    'ScientificProcessEngine',
    'SpeculationEngine',
    'SplitBrainABTest',
    'MultiLLMOrchestrator',
    'AdvancedEngramEngine'
] 