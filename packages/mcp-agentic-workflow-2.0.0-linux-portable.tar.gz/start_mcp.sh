#!/bin/bash
echo "Starting MCP Agentic Workflow Accelerator..."
cd "$(dirname "$0")"
./mcp_agentic_workflow "$@"
