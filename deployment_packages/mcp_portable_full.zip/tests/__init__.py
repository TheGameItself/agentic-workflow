"""
Test suite for the MCP package.

Contains unit tests, integration tests, and test utilities.
""" 