"""
Integration tests for the MCP package.

Tests that verify the interaction between multiple components.
""" 