#!/usr/bin/env python3
"""
Comprehensive System Test
Tests all the new advanced features of the MCP system.
"""

import sys
import os
import sqlite3
from datetime import datetime

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_basic_memory():
    """Test basic memory functionality."""
    print("🧠 Testing Basic Memory System...")
    
    from mcp.memory import MemoryManager
    
    manager = MemoryManager()
    
    # Test adding memory
    memory_id = manager.add_memory(
        "Test memory for system verification",
        "test",
        0.8,
        "Testing context",
        ["test", "verification"]
    )
    print(f"  ✅ Memory added with ID: {memory_id}")
    
    # Test retrieving memory
    memory = manager.get_memory(memory_id)
    if memory and memory['text'] == "Test memory for system verification":
        print("  ✅ Memory retrieval works")
    else:
        print("  ❌ Memory retrieval failed")
    
    # Test searching memories
    results = manager.search_memories("verification", 5)
    if results and len(results) > 0:
        print("  ✅ Memory search works")
    else:
        print("  ❌ Memory search failed")

def test_task_manager():
    """Test task management functionality."""
    print("\n📋 Testing Task Management System...")
    
    from mcp.task_manager import TaskManager
    
    task_manager = TaskManager()
    
    # Test creating task
    task_id = task_manager.create_task(
        title="Test Task",
        description="A test task for verification",
        priority=8,
        estimated_hours=2.0,
        accuracy_critical=True,
        tags=["test", "verification"]
    )
    print(f"  ✅ Task created with ID: {task_id}")
    
    # Test adding task note with line number
    note_id = task_manager.add_task_note(
        task_id,
        "Test note with line reference",
        42,
        "test_file.py",
        "code_reference"
    )
    print(f"  ✅ Task note added with ID: {note_id}")
    
    # Test updating task progress
    success = task_manager.update_task_progress(
        task_id,
        50.0,
        "Halfway through implementation",
        "Need to add error handling"
    )
    if success:
        print("  ✅ Task progress update works")
    else:
        print("  ❌ Task progress update failed")
    
    # Test getting task tree
    task_tree = task_manager.get_task_tree()
    if task_tree and 'root_tasks' in task_tree:
        print("  ✅ Task tree retrieval works")
    else:
        print("  ❌ Task tree retrieval failed")
    
    # Test getting blocked tasks
    blocked_tasks = task_manager.get_blocked_tasks()
    print(f"  ✅ Blocked tasks check works (found {len(blocked_tasks)})")
    
    # Test getting critical tasks
    critical_tasks = task_manager.get_accuracy_critical_tasks()
    if critical_tasks and len(critical_tasks) > 0:
        print("  ✅ Critical tasks detection works")
    else:
        print("  ❌ Critical tasks detection failed")

def test_context_manager():
    """Test context management functionality."""
    print("\n📦 Testing Context Management System...")
    
    from mcp.context_manager import ContextManager
    
    context_manager = ContextManager()
    
    # Test generating context pack
    context_pack = context_manager.generate_context_pack(
        ['tasks', 'blockers', 'progress'],
        500
    )
    
    if context_pack and hasattr(context_pack, 'summary'):
        print("  ✅ Context pack generation works")
        print(f"  📊 Context summary: {context_pack.summary}")
    else:
        print("  ❌ Context pack generation failed")
    
    # Test exporting context for LLM
    context_text = context_manager.export_context_for_llm(
        ['tasks', 'progress'],
        300
    )
    
    if context_text and len(context_text) > 0:
        print("  ✅ Context export for LLM works")
        print(f"  📝 Context length: {len(context_text)} characters")
    else:
        print("  ❌ Context export failed")

def test_unified_memory():
    """Test unified memory functionality."""
    print("\n🔗 Testing Unified Memory System...")
    
    from mcp.unified_memory import UnifiedMemoryManager
    
    unified_manager = UnifiedMemoryManager()
    
    # Test unified memory addition
    result = unified_manager.add_memory(
        "Unified test memory",
        "unified_test",
        0.7,
        "Unified testing context",
        ["unified", "test"],
        use_advanced=True,
        create_reminder=True
    )
    
    if result['success']:
        print("  ✅ Unified memory addition works")
        print(f"  📝 Basic ID: {result['basic_memory_id']}")
        print(f"  📝 Advanced ID: {result['advanced_memory_id']}")
        print(f"  📝 Reminder ID: {result['reminder_id']}")
    else:
        print("  ❌ Unified memory addition failed")
    
    # Test unified search
    search_results = unified_manager.search_memories(
        "unified test",
        search_type='unified',
        limit=5
    )
    
    if search_results and len(search_results) > 0:
        print("  ✅ Unified memory search works")
    else:
        print("  ❌ Unified memory search failed")

def test_cli_commands():
    """Test CLI command availability."""
    print("\n🖥️  Testing CLI Commands...")
    
    try:
        from mcp.cli import cli
        print("  ✅ CLI module imports successfully")
        
        # Check if main commands are available
        commands = cli.commands
        expected_commands = [
            'add-memory', 'search-memories', 'get-memory',
            'create-task', 'list-tasks', 'update-task-progress',
            'add-task-note', 'add-task-dependency', 'show-blocked-tasks',
            'show-critical-tasks', 'export-context', 'get-context-pack',
            'bulk-update-task-status', 'add-task-feedback', 'statistics',
            'task-tree'
        ]
        
        available_commands = list(commands.keys())
        missing_commands = [cmd for cmd in expected_commands if cmd not in available_commands]
        
        if not missing_commands:
            print("  ✅ All expected CLI commands are available")
        else:
            print(f"  ⚠️  Missing CLI commands: {missing_commands}")
            print(f"  📋 Available commands: {available_commands}")
    
    except ImportError as e:
        print(f"  ❌ CLI import failed: {e}")

def test_database_integrity():
    """Test database integrity and schema."""
    print("\n🗄️  Testing Database Integrity...")
    
    # Check if database files exist
    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    db_files = ['memory.db', 'unified_memory.db']
    
    for db_file in db_files:
        db_path = os.path.join(data_dir, db_file)
        if os.path.exists(db_path):
            print(f"  ✅ Database file exists: {db_file}")
            
            # Test database connection
            try:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                
                # Check tables
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]
                
                print(f"  📊 Tables in {db_file}: {tables}")
                
                conn.close()
            except Exception as e:
                print(f"  ❌ Database connection failed for {db_file}: {e}")
        else:
            print(f"  ❌ Database file missing: {db_file}")

def test_requirements():
    """Test that all required dependencies are available."""
    print("\n📦 Testing Dependencies...")
    
    required_packages = ['click', 'sqlite3', 'json', 'datetime']
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"  ✅ {package} is available")
        except ImportError:
            print(f"  ❌ {package} is missing")

def main():
    """Run all tests."""
    print("🚀 Starting Comprehensive MCP System Test")
    print("=" * 50)
    
    try:
        test_requirements()
        test_database_integrity()
        test_basic_memory()
        test_task_manager()
        test_context_manager()
        test_unified_memory()
        test_cli_commands()
        
        print("\n" + "=" * 50)
        print("✅ All tests completed successfully!")
        print("\n🎉 MCP System is ready for use!")
        print("\n📋 Available commands:")
        print("  python mcp.py --help                    # Show all commands")
        print("  python mcp.py create-task --help        # Create a new task")
        print("  python mcp.py export-context --help     # Export context for LLM")
        print("  python mcp.py statistics                # Show system statistics")
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main()) 