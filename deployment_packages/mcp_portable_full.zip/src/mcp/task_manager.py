#!/usr/bin/env python3
"""
Unified Task Management System
Handles priority trees, dependencies, partial completion, and notes with line numbers.
"""

import sqlite3
import json
import os
from typing import List, Dict, Any, Optional, Set
from datetime import datetime, timedelta
from enum import Enum

class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    PARTIAL = "partial"
    COMPLETED = "completed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"

class TaskPriority(Enum):
    CRITICAL = 10
    HIGH = 8
    MEDIUM = 5
    LOW = 2
    MINIMAL = 1

class TaskManager:
    """Unified task management with priority trees and dependencies."""
    
    def __init__(self, db_path: str = None):
        """Initialize the task manager."""
        if db_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.join(current_dir, '..', '..')
            data_dir = os.path.join(project_root, 'data')
            os.makedirs(data_dir, exist_ok=True)
            db_path = os.path.join(data_dir, 'unified_memory.db')
        
        self.db_path = db_path
        self._init_task_database()
    
    def _init_task_database(self):
        """Initialize the task database with advanced schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Enhanced tasks table with priority tree support
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending',
                priority INTEGER DEFAULT 5,
                parent_id INTEGER,
                estimated_hours REAL DEFAULT 0.0,
                actual_hours REAL DEFAULT 0.0,
                accuracy_critical BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                due_date TIMESTAMP,
                FOREIGN KEY (parent_id) REFERENCES tasks (id)
            )
        """)
        
        # Task dependencies table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                depends_on_task_id INTEGER,
                dependency_type TEXT DEFAULT 'blocks',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks (id),
                FOREIGN KEY (depends_on_task_id) REFERENCES tasks (id)
            )
        """)
        
        # Task notes with line numbers
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                note_text TEXT NOT NULL,
                line_number INTEGER,
                file_path TEXT,
                note_type TEXT DEFAULT 'general',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks (id)
            )
        """)
        
        # Task progress tracking
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                progress_percentage REAL DEFAULT 0.0,
                current_step TEXT,
                partial_completion_notes TEXT,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks (id)
            )
        """)
        
        # Task feedback and lessons
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                feedback_text TEXT NOT NULL,
                lesson_learned TEXT,
                principle TEXT,
                impact_score INTEGER DEFAULT 0,
                feedback_type TEXT DEFAULT 'general',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks (id)
            )
        """)
        
        # Task tags and categories
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS task_tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER,
                tag_name TEXT NOT NULL,
                tag_type TEXT DEFAULT 'general',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks (id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def create_task(self, title: str, description: str = None, priority: int = 5,
                   parent_id: int = None, estimated_hours: float = 0.0,
                   accuracy_critical: bool = False, due_date: datetime = None,
                   tags: List[str] = None) -> int:
        """Create a new task with full metadata."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO tasks (title, description, priority, parent_id, 
                              estimated_hours, accuracy_critical, due_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (title, description, priority, parent_id, estimated_hours, 
              accuracy_critical, due_date))
        
        task_id = cursor.lastrowid
        
        # Add tags if provided
        if tags:
            for tag in tags:
                cursor.execute("""
                    INSERT INTO task_tags (task_id, tag_name)
                    VALUES (?, ?)
                """, (task_id, tag))
        
        # Initialize progress tracking
        cursor.execute("""
            INSERT INTO task_progress (task_id, progress_percentage, current_step)
            VALUES (?, ?, ?)
        """, (task_id, 0.0, "Not started"))
        
        conn.commit()
        conn.close()
        
        return task_id
    
    def add_task_dependency(self, task_id: int, depends_on_task_id: int,
                           dependency_type: str = 'blocks') -> int:
        """Add a dependency between tasks."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO task_dependencies (task_id, depends_on_task_id, dependency_type)
            VALUES (?, ?, ?)
        """, (task_id, depends_on_task_id, dependency_type))
        
        dependency_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return dependency_id
    
    def add_task_note(self, task_id: int, note_text: str, line_number: int = None,
                     file_path: str = None, note_type: str = 'general') -> int:
        """Add a note to a task with optional line number and file path."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO task_notes (task_id, note_text, line_number, file_path, note_type)
            VALUES (?, ?, ?, ?, ?)
        """, (task_id, note_text, line_number, file_path, note_type))
        
        note_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return note_id
    
    def update_task_progress(self, task_id: int, progress_percentage: float,
                           current_step: str = None, partial_completion_notes: str = None) -> bool:
        """Update task progress with partial completion support."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Update progress
        cursor.execute("""
            UPDATE task_progress 
            SET progress_percentage = ?, current_step = ?, partial_completion_notes = ?,
                last_updated = ?
            WHERE task_id = ?
        """, (progress_percentage, current_step, partial_completion_notes, 
              datetime.now(), task_id))
        
        # Update task status based on progress
        if progress_percentage >= 100.0:
            status = TaskStatus.COMPLETED.value
            completed_at = datetime.now()
        elif progress_percentage > 0:
            status = TaskStatus.IN_PROGRESS.value
            completed_at = None
        else:
            status = TaskStatus.PENDING.value
            completed_at = None
        
        cursor.execute("""
            UPDATE tasks 
            SET status = ?, completed_at = ?, updated_at = ?
            WHERE id = ?
        """, (status, completed_at, datetime.now(), task_id))
        
        conn.commit()
        conn.close()
        
        return True
    
    def get_task_tree(self, root_task_id: int = None, include_completed: bool = False) -> Dict[str, Any]:
        """Get the complete task tree structure."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if root_task_id:
            # Get specific subtree
            cursor.execute("""
                WITH RECURSIVE task_tree AS (
                    SELECT id, title, description, status, priority, parent_id,
                           estimated_hours, actual_hours, accuracy_critical,
                           created_at, updated_at, started_at, completed_at, due_date,
                           0 as level
                    FROM tasks WHERE id = ?
                    UNION ALL
                    SELECT t.id, t.title, t.description, t.status, t.priority, t.parent_id,
                           t.estimated_hours, t.actual_hours, t.accuracy_critical,
                           t.created_at, t.updated_at, t.started_at, t.completed_at, t.due_date,
                           tt.level + 1
                    FROM tasks t
                    JOIN task_tree tt ON t.parent_id = tt.id
                )
                SELECT * FROM task_tree
                ORDER BY level, priority DESC, created_at ASC
            """, (root_task_id,))
        else:
            # Get all tasks
            status_filter = "" if include_completed else "WHERE status != 'completed'"
            cursor.execute(f"""
                SELECT id, title, description, status, priority, parent_id,
                       estimated_hours, actual_hours, accuracy_critical,
                       created_at, updated_at, started_at, completed_at, due_date
                FROM tasks {status_filter}
                ORDER BY priority DESC, created_at ASC
            """)
        
        tasks = cursor.fetchall()
        conn.close()
        
        # Build tree structure
        task_dict = {}
        root_tasks = []
        
        for task in tasks:
            task_id, title, description, status, priority, parent_id, \
            estimated_hours, actual_hours, accuracy_critical, created_at, \
            updated_at, started_at, completed_at, due_date = task
            
            task_data = {
                'id': task_id,
                'title': title,
                'description': description,
                'status': status,
                'priority': priority,
                'parent_id': parent_id,
                'estimated_hours': estimated_hours,
                'actual_hours': actual_hours,
                'accuracy_critical': accuracy_critical,
                'created_at': created_at,
                'updated_at': updated_at,
                'started_at': started_at,
                'completed_at': completed_at,
                'due_date': due_date,
                'children': [],
                'dependencies': self.get_task_dependencies(task_id),
                'notes': self.get_task_notes(task_id),
                'progress': self.get_task_progress(task_id)
            }
            
            task_dict[task_id] = task_data
            
            if parent_id is None:
                root_tasks.append(task_data)
            else:
                if parent_id in task_dict:
                    task_dict[parent_id]['children'].append(task_data)
        
        return {
            'root_tasks': root_tasks,
            'all_tasks': task_dict
        }
    
    def get_task_dependencies(self, task_id: int) -> List[Dict[str, Any]]:
        """Get dependencies for a specific task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT td.id, td.dependency_type, t.id, t.title, t.status, t.priority
            FROM task_dependencies td
            JOIN tasks t ON td.depends_on_task_id = t.id
            WHERE td.task_id = ?
        """, (task_id,))
        
        dependencies = []
        for row in cursor.fetchall():
            dep_id, dep_type, dep_task_id, dep_title, dep_status, dep_priority = row
            dependencies.append({
                'dependency_id': dep_id,
                'dependency_type': dep_type,
                'task_id': dep_task_id,
                'title': dep_title,
                'status': dep_status,
                'priority': dep_priority
            })
        
        conn.close()
        return dependencies
    
    def get_task_notes(self, task_id: int) -> List[Dict[str, Any]]:
        """Get notes for a specific task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, note_text, line_number, file_path, note_type, created_at
            FROM task_notes WHERE task_id = ?
            ORDER BY created_at ASC
        """, (task_id,))
        
        notes = []
        for row in cursor.fetchall():
            note_id, note_text, line_number, file_path, note_type, created_at = row
            notes.append({
                'id': note_id,
                'note_text': note_text,
                'line_number': line_number,
                'file_path': file_path,
                'note_type': note_type,
                'created_at': created_at
            })
        
        conn.close()
        return notes
    
    def get_task_progress(self, task_id: int) -> Dict[str, Any]:
        """Get progress information for a specific task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT progress_percentage, current_step, partial_completion_notes, last_updated
            FROM task_progress WHERE task_id = ?
        """, (task_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            progress_percentage, current_step, partial_completion_notes, last_updated = row
            return {
                'progress_percentage': progress_percentage,
                'current_step': current_step,
                'partial_completion_notes': partial_completion_notes,
                'last_updated': last_updated
            }
        
        return {
            'progress_percentage': 0.0,
            'current_step': 'Not started',
            'partial_completion_notes': None,
            'last_updated': None
        }
    
    def get_blocked_tasks(self) -> List[Dict[str, Any]]:
        """Get tasks that are blocked by incomplete dependencies."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT DISTINCT t.id, t.title, t.status, t.priority,
                   GROUP_CONCAT(dep.title) as blocking_tasks
            FROM tasks t
            JOIN task_dependencies td ON t.id = td.task_id
            JOIN tasks dep ON td.depends_on_task_id = dep.id
            WHERE dep.status != 'completed' AND t.status != 'completed'
            GROUP BY t.id
            ORDER BY t.priority DESC
        """)
        
        blocked_tasks = []
        for row in cursor.fetchall():
            task_id, title, status, priority, blocking_tasks = row
            blocked_tasks.append({
                'id': task_id,
                'title': title,
                'status': status,
                'priority': priority,
                'blocking_tasks': blocking_tasks.split(',') if blocking_tasks else []
            })
        
        conn.close()
        return blocked_tasks
    
    def get_accuracy_critical_tasks(self) -> List[Dict[str, Any]]:
        """Get tasks marked as accuracy-critical."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, title, description, status, priority, estimated_hours,
                   created_at, due_date
            FROM tasks 
            WHERE accuracy_critical = TRUE
            ORDER BY priority DESC, created_at ASC
        """)
        
        critical_tasks = []
        for row in cursor.fetchall():
            task_id, title, description, status, priority, estimated_hours, created_at, due_date = row
            critical_tasks.append({
                'id': task_id,
                'title': title,
                'description': description,
                'status': status,
                'priority': priority,
                'estimated_hours': estimated_hours,
                'created_at': created_at,
                'due_date': due_date
            })
        
        conn.close()
        return critical_tasks
    
    def add_task_feedback(self, task_id: int, feedback_text: str, lesson_learned: str = None,
                         principle: str = None, impact_score: int = 0,
                         feedback_type: str = 'general') -> int:
        """Add feedback and lessons learned to a task."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO task_feedback 
            (task_id, feedback_text, lesson_learned, principle, impact_score, feedback_type)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (task_id, feedback_text, lesson_learned, principle, impact_score, feedback_type))
        
        feedback_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return feedback_id
    
    def get_task_statistics(self) -> Dict[str, Any]:
        """Get comprehensive task statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Basic counts
        cursor.execute("SELECT COUNT(*) FROM tasks")
        total_tasks = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM tasks WHERE status = 'completed'")
        completed_tasks = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM tasks WHERE accuracy_critical = TRUE")
        critical_tasks = cursor.fetchone()[0]
        
        # Status distribution
        cursor.execute("""
            SELECT status, COUNT(*) FROM tasks GROUP BY status
        """)
        status_distribution = dict(cursor.fetchall())
        
        # Priority distribution
        cursor.execute("""
            SELECT priority, COUNT(*) FROM tasks GROUP BY priority ORDER BY priority DESC
        """)
        priority_distribution = dict(cursor.fetchall())
        
        # Time tracking
        cursor.execute("""
            SELECT SUM(estimated_hours), SUM(actual_hours) FROM tasks
        """)
        time_data = cursor.fetchone()
        total_estimated = time_data[0] or 0
        total_actual = time_data[1] or 0
        
        conn.close()
        
        return {
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'critical_tasks': critical_tasks,
            'completion_rate': (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0,
            'status_distribution': status_distribution,
            'priority_distribution': priority_distribution,
            'time_tracking': {
                'total_estimated_hours': total_estimated,
                'total_actual_hours': total_actual,
                'accuracy': (total_actual / total_estimated * 100) if total_estimated > 0 else 0
            }
        } 