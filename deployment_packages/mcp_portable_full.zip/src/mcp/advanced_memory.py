#!/usr/bin/env python3
"""
Advanced Memory Management System
Implements vector search, categorization, relationships, and quality assessment.
"""

import sqlite3
import json
import os
import re
import math
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import hashlib

class AdvancedMemoryManager:
    """Advanced memory management with vector search, categorization, and relationships."""
    
    def __init__(self, db_path: str = None):
        """Initialize the advanced memory manager."""
        if db_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.join(current_dir, '..', '..')
            data_dir = os.path.join(project_root, 'data')
            os.makedirs(data_dir, exist_ok=True)
            db_path = os.path.join(data_dir, 'unified_memory.db')
        
        self.db_path = db_path
        self._init_advanced_database()
    
    def _init_advanced_database(self):
        """Initialize the advanced database schema."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Advanced memories table with vector embeddings
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS advanced_memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                memory_type TEXT DEFAULT 'general',
                priority REAL DEFAULT 0.5,
                context TEXT,
                tags TEXT,
                category TEXT,
                vector_embedding TEXT,
                quality_score REAL DEFAULT 0.5,
                confidence_score REAL DEFAULT 0.5,
                completeness_score REAL DEFAULT 0.5,
                relevance_score REAL DEFAULT 0.5,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                access_count INTEGER DEFAULT 0
            )
        """)
        
        # Memory relationships table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memory_relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_memory_id INTEGER,
                target_memory_id INTEGER,
                relationship_type TEXT,
                strength REAL DEFAULT 0.5,
                confidence REAL DEFAULT 0.5,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (source_memory_id) REFERENCES advanced_memories (id),
                FOREIGN KEY (target_memory_id) REFERENCES advanced_memories (id)
            )
        """)
        
        # Memory categories table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memory_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                parent_category_id INTEGER,
                confidence REAL DEFAULT 0.5,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (parent_category_id) REFERENCES memory_categories (id)
            )
        """)
        
        # Enhanced reminders table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS enhanced_reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id INTEGER,
                task_id INTEGER,
                reminder_type TEXT,
                trigger_conditions TEXT,
                next_reminder TIMESTAMP,
                reminder_count INTEGER DEFAULT 0,
                last_triggered TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                effectiveness_score REAL DEFAULT 0.0,
                user_feedback_history TEXT,
                easiness_factor REAL DEFAULT 2.5,
                context_history TEXT,
                FOREIGN KEY (memory_id) REFERENCES advanced_memories (id)
            )
        """)
        
        # Context patterns table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS context_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_type TEXT,
                pattern_data TEXT,
                confidence REAL DEFAULT 1.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # User retention rates table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_retention_rates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                content_type TEXT,
                retention_rate REAL DEFAULT 0.5,
                sample_count INTEGER DEFAULT 0,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
    
    def _create_tfidf_embedding(self, text: str) -> Dict[str, float]:
        """Create TF-IDF embedding for text."""
        # Simple TF-IDF implementation
        words = re.findall(r'\b\w+\b', text.lower())
        word_freq = Counter(words)
        
        # Calculate TF
        total_words = len(words)
        tf = {word: freq / total_words for word, freq in word_freq.items()}
        
        # For simplicity, we'll use a basic IDF calculation
        # In a real implementation, you'd calculate this across all documents
        idf = {word: 1.0 for word in tf.keys()}
        
        # Calculate TF-IDF
        tfidf = {word: tf[word] * idf[word] for word in tf.keys()}
        
        return tfidf
    
    def _cosine_similarity(self, vec1: Dict[str, float], vec2: Dict[str, float]) -> float:
        """Calculate cosine similarity between two vectors."""
        # Get all unique words
        all_words = set(vec1.keys()) | set(vec2.keys())
        
        if not all_words:
            return 0.0
        
        # Calculate dot product and magnitudes
        dot_product = sum(vec1.get(word, 0) * vec2.get(word, 0) for word in all_words)
        mag1 = math.sqrt(sum(vec1.get(word, 0) ** 2 for word in all_words))
        mag2 = math.sqrt(sum(vec2.get(word, 0) ** 2 for word in all_words))
        
        if mag1 == 0 or mag2 == 0:
            return 0.0
        
        return dot_product / (mag1 * mag2)
    
    def add_advanced_memory(self, text: str, memory_type: str = 'general', 
                           priority: float = 0.5, context: str = None, 
                           tags: List[str] = None, category: str = None) -> int:
        """Add a new advanced memory with vector embedding."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create vector embedding
        embedding = self._create_tfidf_embedding(text)
        embedding_json = json.dumps(embedding)
        
        # Auto-detect category if not provided
        if not category:
            category = self._auto_detect_category(text, tags)
        
        # Calculate quality scores
        quality_score = self._calculate_quality_score(text, context, tags)
        confidence_score = self._calculate_confidence_score(text, context)
        completeness_score = self._calculate_completeness_score(text, context)
        relevance_score = self._calculate_relevance_score(text, tags)
        
        tags_json = json.dumps(tags) if tags else None
        
        cursor.execute("""
            INSERT INTO advanced_memories 
            (text, memory_type, priority, context, tags, category, vector_embedding,
             quality_score, confidence_score, completeness_score, relevance_score)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (text, memory_type, priority, context, tags_json, category, embedding_json,
              quality_score, confidence_score, completeness_score, relevance_score))
        
        memory_id = cursor.lastrowid
        
        # Auto-detect relationships with existing memories
        self._auto_detect_relationships(memory_id, text, embedding)
        
        conn.commit()
        conn.close()
        
        return memory_id
    
    def _auto_detect_category(self, text: str, tags: List[str] = None) -> str:
        """Auto-detect category based on text content and tags."""
        # Simple keyword-based category detection
        text_lower = text.lower()
        
        category_keywords = {
            'code': ['function', 'class', 'method', 'api', 'bug', 'error', 'debug'],
            'research': ['study', 'analysis', 'investigation', 'research', 'paper'],
            'planning': ['plan', 'strategy', 'roadmap', 'timeline', 'milestone'],
            'documentation': ['doc', 'readme', 'comment', 'guide', 'tutorial'],
            'testing': ['test', 'unit', 'integration', 'validation', 'verify'],
            'deployment': ['deploy', 'production', 'server', 'config', 'environment']
        }
        
        # Check text content
        for category, keywords in category_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                return category
        
        # Check tags
        if tags:
            for tag in tags:
                tag_lower = tag.lower()
                for category, keywords in category_keywords.items():
                    if any(keyword in tag_lower for keyword in keywords):
                        return category
        
        return 'general'
    
    def _calculate_quality_score(self, text: str, context: str = None, tags: List[str] = None) -> float:
        """Calculate memory quality score."""
        score = 0.5  # Base score
        
        # Text length factor
        if len(text) > 50:
            score += 0.1
        if len(text) > 200:
            score += 0.1
        
        # Context factor
        if context:
            score += 0.1
        
        # Tags factor
        if tags and len(tags) > 0:
            score += 0.1
        
        # Specificity factor (more specific terms)
        specific_terms = ['because', 'therefore', 'however', 'specifically', 'example']
        if any(term in text.lower() for term in specific_terms):
            score += 0.1
        
        return min(score, 1.0)
    
    def _calculate_confidence_score(self, text: str, context: str = None) -> float:
        """Calculate confidence score for the memory."""
        score = 0.5  # Base score
        
        # Context presence
        if context:
            score += 0.2
        
        # Text clarity (simple heuristic)
        if len(text.split()) > 10:
            score += 0.1
        
        # Specific details
        if re.search(r'\d+', text):  # Contains numbers
            score += 0.1
        
        return min(score, 1.0)
    
    def _calculate_completeness_score(self, text: str, context: str = None) -> float:
        """Calculate completeness score for the memory."""
        score = 0.5  # Base score
        
        # Context completeness
        if context:
            score += 0.2
        
        # Text completeness
        if len(text.split()) > 20:
            score += 0.2
        
        # Structured information
        if re.search(r'[A-Z][a-z]+:', text):  # Contains structured info
            score += 0.1
        
        return min(score, 1.0)
    
    def _calculate_relevance_score(self, text: str, tags: List[str] = None) -> float:
        """Calculate relevance score for the memory."""
        score = 0.5  # Base score
        
        # Tag relevance
        if tags and len(tags) > 0:
            score += 0.2
        
        # Text relevance (simple keyword matching)
        relevant_keywords = ['important', 'key', 'critical', 'essential', 'must']
        if any(keyword in text.lower() for keyword in relevant_keywords):
            score += 0.2
        
        return min(score, 1.0)
    
    def _auto_detect_relationships(self, memory_id: int, text: str, embedding: Dict[str, float]):
        """Auto-detect relationships with existing memories."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get existing memories
        cursor.execute("""
            SELECT id, text, vector_embedding FROM advanced_memories 
            WHERE id != ? ORDER BY created_at DESC LIMIT 50
        """, (memory_id,))
        
        existing_memories = cursor.fetchall()
        
        for existing_id, existing_text, existing_embedding_json in existing_memories:
            try:
                existing_embedding = json.loads(existing_embedding_json)
                similarity = self._cosine_similarity(embedding, existing_embedding)
                
                # Create relationship if similarity is high enough
                if similarity > 0.3:
                    relationship_type = self._determine_relationship_type(text, existing_text)
                    
                    cursor.execute("""
                        INSERT INTO memory_relationships 
                        (source_memory_id, target_memory_id, relationship_type, strength, confidence)
                        VALUES (?, ?, ?, ?, ?)
                    """, (memory_id, existing_id, relationship_type, similarity, similarity))
            
            except (json.JSONDecodeError, KeyError):
                continue
        
        conn.commit()
        conn.close()
    
    def _determine_relationship_type(self, text1: str, text2: str) -> str:
        """Determine the type of relationship between two memories."""
        text1_lower = text1.lower()
        text2_lower = text2.lower()
        
        # Check for semantic relationships
        if any(word in text1_lower and word in text2_lower 
               for word in ['error', 'bug', 'fix', 'issue']):
            return 'problem_solution'
        
        if any(word in text1_lower and word in text2_lower 
               for word in ['function', 'method', 'class', 'api']):
            return 'code_related'
        
        if any(word in text1_lower and word in text2_lower 
               for word in ['research', 'study', 'analysis']):
            return 'research_related'
        
        return 'semantic_similarity'
    
    def vector_search(self, query: str, limit: int = 10, 
                     memory_type: str = None, min_similarity: float = 0.1) -> List[Dict[str, Any]]:
        """Search memories using vector similarity."""
        query_embedding = self._create_tfidf_embedding(query)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if memory_type:
            cursor.execute("""
                SELECT id, text, memory_type, priority, context, tags, category,
                       vector_embedding, quality_score, confidence_score,
                       completeness_score, relevance_score, created_at
                FROM advanced_memories 
                WHERE memory_type = ?
                ORDER BY created_at DESC
            """, (memory_type,))
        else:
            cursor.execute("""
                SELECT id, text, memory_type, priority, context, tags, category,
                       vector_embedding, quality_score, confidence_score,
                       completeness_score, relevance_score, created_at
                FROM advanced_memories 
                ORDER BY created_at DESC
            """)
        
        memories = cursor.fetchall()
        conn.close()
        
        # Calculate similarities
        similarities = []
        for memory in memories:
            try:
                memory_embedding = json.loads(memory[7])  # vector_embedding
                similarity = self._cosine_similarity(query_embedding, memory_embedding)
                
                if similarity >= min_similarity:
                    similarities.append((similarity, memory))
            except (json.JSONDecodeError, KeyError):
                continue
        
        # Sort by similarity and return top results
        similarities.sort(key=lambda x: x[0], reverse=True)
        
        results = []
        for similarity, memory in similarities[:limit]:
            memory_id, text, memory_type, priority, context, tags_json, category, \
            vector_embedding, quality_score, confidence_score, completeness_score, \
            relevance_score, created_at = memory
            
            tags = json.loads(tags_json) if tags_json else None
            
            results.append({
                'id': memory_id,
                'text': text,
                'memory_type': memory_type,
                'priority': priority,
                'context': context,
                'tags': tags,
                'category': category,
                'similarity': similarity,
                'quality_score': quality_score,
                'confidence_score': confidence_score,
                'completeness_score': completeness_score,
                'relevance_score': relevance_score,
                'created_at': created_at
            })
        
        return results
    
    def get_memory_relationships(self, memory_id: int) -> List[Dict[str, Any]]:
        """Get relationships for a specific memory."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT r.id, r.relationship_type, r.strength, r.confidence,
                   m.id, m.text, m.memory_type, m.category
            FROM memory_relationships r
            JOIN advanced_memories m ON r.target_memory_id = m.id
            WHERE r.source_memory_id = ?
            ORDER BY r.strength DESC
        """, (memory_id,))
        
        relationships = []
        for row in cursor.fetchall():
            rel_id, rel_type, strength, confidence, target_id, target_text, target_type, target_category = row
            
            relationships.append({
                'relationship_id': rel_id,
                'relationship_type': rel_type,
                'strength': strength,
                'confidence': confidence,
                'target_memory': {
                    'id': target_id,
                    'text': target_text,
                    'memory_type': target_type,
                    'category': target_category
                }
            })
        
        conn.close()
        return relationships
    
    def get_memory_quality_report(self, memory_id: int) -> Dict[str, Any]:
        """Generate a quality report for a memory."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT quality_score, confidence_score, completeness_score, relevance_score,
                   text, context, tags, category, created_at, last_accessed, access_count
            FROM advanced_memories WHERE id = ?
        """, (memory_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return None
        
        quality_score, confidence_score, completeness_score, relevance_score, \
        text, context, tags_json, category, created_at, last_accessed, access_count = row
        
        tags = json.loads(tags_json) if tags_json else None
        
        # Calculate overall quality
        overall_quality = (quality_score + confidence_score + completeness_score + relevance_score) / 4
        
        # Generate improvement suggestions
        suggestions = []
        if quality_score < 0.7:
            suggestions.append("Add more context or details to improve quality")
        if confidence_score < 0.7:
            suggestions.append("Provide more specific information to increase confidence")
        if completeness_score < 0.7:
            suggestions.append("Include additional relevant information for completeness")
        if relevance_score < 0.7:
            suggestions.append("Add relevant tags or keywords to improve relevance")
        
        return {
            'memory_id': memory_id,
            'overall_quality': overall_quality,
            'quality_breakdown': {
                'quality_score': quality_score,
                'confidence_score': confidence_score,
                'completeness_score': completeness_score,
                'relevance_score': relevance_score
            },
            'content_info': {
                'text_length': len(text),
                'has_context': bool(context),
                'tag_count': len(tags) if tags else 0,
                'category': category
            },
            'usage_info': {
                'created_at': created_at,
                'last_accessed': last_accessed,
                'access_count': access_count
            },
            'improvement_suggestions': suggestions
        }
    
    def get_memory(self, memory_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific advanced memory by ID."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, text, memory_type, priority, context, tags, category,
                   vector_embedding, quality_score, confidence_score, 
                   completeness_score, relevance_score, created_at, updated_at,
                   last_accessed, access_count
            FROM advanced_memories 
            WHERE id = ?
        """, (memory_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'text': row[1],
                'memory_type': row[2],
                'priority': row[3],
                'context': row[4],
                'tags': json.loads(row[5]) if row[5] else [],
                'category': row[6],
                'vector_embedding': json.loads(row[7]) if row[7] else {},
                'quality_score': row[8],
                'confidence_score': row[9],
                'completeness_score': row[10],
                'relevance_score': row[11],
                'created_at': row[12],
                'updated_at': row[13],
                'last_accessed': row[14],
                'access_count': row[15]
            }
        
        return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get advanced memory statistics."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Basic counts
        cursor.execute("SELECT COUNT(*) FROM advanced_memories")
        total_memories = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM memory_relationships")
        total_relationships = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM enhanced_reminders")
        total_reminders = cursor.fetchone()[0]
        
        # Category distribution
        cursor.execute("""
            SELECT category, COUNT(*) FROM advanced_memories 
            GROUP BY category ORDER BY COUNT(*) DESC
        """)
        category_distribution = dict(cursor.fetchall())
        
        # Quality distribution
        cursor.execute("""
            SELECT 
                CASE 
                    WHEN quality_score >= 0.8 THEN 'high'
                    WHEN quality_score >= 0.6 THEN 'medium'
                    ELSE 'low'
                END as quality_level,
                COUNT(*)
            FROM advanced_memories 
            GROUP BY quality_level
        """)
        quality_distribution = dict(cursor.fetchall())
        
        # Average scores
        cursor.execute("""
            SELECT AVG(quality_score), AVG(confidence_score), 
                   AVG(completeness_score), AVG(relevance_score)
            FROM advanced_memories
        """)
        avg_scores = cursor.fetchone()
        
        conn.close()
        
        return {
            'total_memories': total_memories,
            'total_relationships': total_relationships,
            'total_reminders': total_reminders,
            'category_distribution': category_distribution,
            'quality_distribution': quality_distribution,
            'average_scores': {
                'quality': avg_scores[0] or 0,
                'confidence': avg_scores[1] or 0,
                'completeness': avg_scores[2] or 0,
                'relevance': avg_scores[3] or 0
            }
        } 