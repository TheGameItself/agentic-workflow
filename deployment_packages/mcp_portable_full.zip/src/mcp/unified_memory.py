#!/usr/bin/env python3
"""
Unified Memory Management System
Combines basic memory, advanced memory, and reminder features into a cohesive interface.
"""

import sqlite3
import json
import os
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta

from .memory import MemoryManager
from .advanced_memory import AdvancedMemoryManager
from .reminder_engine import EnhancedReminderEngine

class UnifiedMemoryManager:
    """Unified memory management system combining all features."""
    
    def __init__(self, db_path: str = None):
        """Initialize the unified memory manager."""
        if db_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.join(current_dir, '..', '..')
            data_dir = os.path.join(project_root, 'data')
            os.makedirs(data_dir, exist_ok=True)
            db_path = os.path.join(data_dir, 'unified_memory.db')
        
        self.db_path = db_path
        self.basic_memory = MemoryManager(db_path)
        self.advanced_memory = AdvancedMemoryManager(db_path)
        self.reminder_engine = EnhancedReminderEngine(db_path)
        self._init_unified_database()
    
    def _init_unified_database(self):
        """Initialize unified database with cross-references."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Unified memory mapping table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS unified_memory_mapping (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                basic_memory_id INTEGER,
                advanced_memory_id INTEGER,
                mapping_type TEXT DEFAULT 'auto',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (basic_memory_id) REFERENCES memories (id),
                FOREIGN KEY (advanced_memory_id) REFERENCES advanced_memories (id)
            )
        """)
        
        # Memory access tracking
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memory_access_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                memory_id INTEGER,
                access_type TEXT,
                context TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                user_id TEXT DEFAULT 'default'
            )
        """)
        
        conn.commit()
        conn.close()
    
    def add_memory(self, text: str, memory_type: str = 'general', 
                   priority: float = 0.5, context: str = None, 
                   tags: List[str] = None, use_advanced: bool = True,
                   create_reminder: bool = False) -> Dict[str, Any]:
        """Add a memory using the unified system."""
        result = {
            'basic_memory_id': None,
            'advanced_memory_id': None,
            'reminder_id': None,
            'success': False
        }
        
        try:
            # Add to basic memory system
            basic_id = self.basic_memory.add_memory(text, memory_type, priority, context, tags)
            result['basic_memory_id'] = basic_id
            
            # Add to advanced memory system if requested
            if use_advanced and basic_id:
                try:
                    advanced_id = self.advanced_memory.add_advanced_memory(
                        text, memory_type, priority, context, tags
                    )
                    result['advanced_memory_id'] = advanced_id
                    
                    # Create mapping
                    if basic_id and advanced_id:
                        self._create_memory_mapping(basic_id, advanced_id)
                    
                    # Create reminder if requested
                    if create_reminder and advanced_id:
                        try:
                            reminder_id = self.reminder_engine.create_spaced_repetition_reminder(advanced_id)
                            result['reminder_id'] = reminder_id
                        except Exception as e:
                            print(f"Warning: Could not create reminder: {e}")
                            
                except Exception as e:
                    print(f"Warning: Could not add to advanced memory: {e}")
            
            result['success'] = True
            
        except Exception as e:
            result['error'] = str(e)
            print(f"Error adding memory: {e}")
        
        return result
    
    def _create_memory_mapping(self, basic_id: int, advanced_id: int):
        """Create mapping between basic and advanced memories."""
        try:
            # Use direct SQLite with proper connection handling
            conn = sqlite3.connect(self.db_path, timeout=60.0)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO unified_memory_mapping (basic_memory_id, advanced_memory_id)
                VALUES (?, ?)
            """, (basic_id, advanced_id))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Warning: Could not create memory mapping: {e}")
    
    def search_memories(self, query: str, search_type: str = 'unified', 
                       limit: int = 10, memory_type: str = None,
                       use_vector_search: bool = True) -> List[Dict[str, Any]]:
        """Search memories using the unified system."""
        results = []
        
        if search_type == 'basic' or search_type == 'unified':
            # Basic search
            basic_results = self.basic_memory.search_memories(query, limit, memory_type)
            for result in basic_results:
                result['search_type'] = 'basic'
                result['source'] = 'basic_memory'
                results.append(result)
        
        if search_type == 'advanced' or search_type == 'unified':
            # Advanced search
            if use_vector_search:
                advanced_results = self.advanced_memory.vector_search(query, limit, memory_type)
            else:
                # Fallback to basic search for advanced memories
                advanced_results = self.basic_memory.search_memories(query, limit, memory_type)
            
            for result in advanced_results:
                result['search_type'] = 'advanced'
                result['source'] = 'advanced_memory'
                results.append(result)
        
        # Sort by relevance/priority
        if search_type == 'unified':
            results.sort(key=lambda x: x.get('priority', 0) + x.get('similarity', 0), reverse=True)
        
        return results[:limit]
    
    def get_memory_details(self, memory_id: int, include_relationships: bool = True,
                          include_quality_report: bool = True) -> Dict[str, Any]:
        """Get comprehensive memory details."""
        details = {}
        
        # Try to get from basic memory first
        basic_memory = self.basic_memory.get_memory(memory_id)
        if basic_memory:
            details['basic_memory'] = basic_memory
            details['source'] = 'basic'
        
        # Try to get from advanced memory
        advanced_memory = self.advanced_memory.get_memory(memory_id)
        if advanced_memory:
            details['advanced_memory'] = advanced_memory
            details['source'] = 'advanced'
        
        # Get relationships if requested
        if include_relationships and 'advanced_memory' in details:
            relationships = self.advanced_memory.get_memory_relationships(memory_id)
            details['relationships'] = relationships
        
        # Get quality report if requested
        if include_quality_report and 'advanced_memory' in details:
            quality_report = self.advanced_memory.get_memory_quality_report(memory_id)
            details['quality_report'] = quality_report
        
        # Get related reminders
        reminders = self.reminder_engine.check_due_reminders()
        memory_reminders = [r for r in reminders if r['memory_id'] == memory_id]
        details['reminders'] = memory_reminders
        
        return details
    
    def add_task(self, description: str, priority: int = 0, parent_id: int = None,
                 create_reminder: bool = False) -> Dict[str, Any]:
        """Add a task with optional reminder."""
        result = {
            'task_id': None,
            'reminder_id': None,
            'success': False
        }
        
        try:
            task_id = self.basic_memory.add_task(description, priority, parent_id)
            result['task_id'] = task_id
            
            if create_reminder:
                # Create a context-aware reminder for the task
                reminder_id = self.reminder_engine.create_context_aware_reminder(
                    task_id, [description.lower()], f"Task: {description}"
                )
                result['reminder_id'] = reminder_id
            
            result['success'] = True
            
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def get_tasks(self, status: str = None, include_reminders: bool = True) -> List[Dict[str, Any]]:
        """Get tasks with optional reminder information."""
        tasks = self.basic_memory.get_tasks(status)
        
        if include_reminders:
            reminders = self.reminder_engine.check_due_reminders()
            reminder_map = {r['memory_id']: r for r in reminders}
            
            for task in tasks:
                task['reminders'] = reminder_map.get(task['id'], None)
        
        return tasks
    
    def complete_task(self, task_id: int, feedback: str = None, 
                     impact: int = 0, principle: str = None) -> Dict[str, Any]:
        """Complete a task with optional feedback."""
        result = {
            'success': False,
            'feedback_id': None
        }
        
        try:
            # Complete the task
            success = self.basic_memory.complete_task(task_id)
            result['success'] = success
            
            # Add feedback if provided
            if feedback and success:
                feedback_id = self.basic_memory.add_feedback(task_id, feedback, impact, principle)
                result['feedback_id'] = feedback_id
            
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def get_due_reminders(self, current_context: str = None) -> List[Dict[str, Any]]:
        """Get all due reminders with enhanced context."""
        reminders = self.reminder_engine.check_due_reminders(current_context)
        
        # Enhance reminders with memory details
        enhanced_reminders = []
        for reminder in reminders:
            memory_details = self.get_memory_details(reminder['memory_id'], 
                                                   include_relationships=False,
                                                   include_quality_report=False)
            
            enhanced_reminder = {
                **reminder,
                'memory_details': memory_details.get('basic_memory') or memory_details.get('advanced_memory')
            }
            enhanced_reminders.append(enhanced_reminder)
        
        return enhanced_reminders
    
    def process_reminder_feedback(self, reminder_id: int, feedback_score: int,
                                response_time_seconds: int = None) -> bool:
        """Process feedback for a reminder."""
        return self.reminder_engine.process_reminder_feedback(
            reminder_id, feedback_score, response_time_seconds
        )
    
    def get_memory_suggestions(self, context: str = None, limit: int = 5) -> List[Dict[str, Any]]:
        """Get personalized memory suggestions."""
        suggestions = []
        
        # Get reminder suggestions
        reminder_suggestions = self.reminder_engine.get_personalized_reminder_suggestions(context)
        suggestions.extend(reminder_suggestions)
        
        # Get related memories based on context
        if context:
            related_memories = self.search_memories(context, 'advanced', limit, use_vector_search=True)
            for memory in related_memories:
                suggestions.append({
                    'memory_id': memory['id'],
                    'text': memory['text'][:100] + '...' if len(memory['text']) > 100 else memory['text'],
                    'memory_type': memory['memory_type'],
                    'category': memory.get('category'),
                    'suggestion_score': memory.get('similarity', 0.5),
                    'suggested_reminder_type': 'context_aware',
                    'reason': f"Related to current context: {context}"
                })
        
        # Sort by suggestion score and return top results
        suggestions.sort(key=lambda x: x['suggestion_score'], reverse=True)
        return suggestions[:limit]
    
    def get_comprehensive_statistics(self) -> Dict[str, Any]:
        """Get comprehensive system statistics."""
        stats = {}
        
        # Basic memory statistics
        basic_stats = self.basic_memory.get_statistics()
        stats['basic_memory'] = basic_stats
        
        # Advanced memory statistics
        advanced_stats = self.advanced_memory.get_statistics()
        stats['advanced_memory'] = advanced_stats
        
        # Reminder statistics
        reminder_stats = self.reminder_engine.get_reminder_statistics()
        stats['reminders'] = reminder_stats
        
        # Unified statistics
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM unified_memory_mapping")
        total_mappings = cursor.fetchone()[0]
        
        cursor.execute("""
            SELECT COUNT(*) FROM memory_access_log 
            WHERE timestamp >= datetime('now', '-7 days')
        """)
        weekly_accesses = cursor.fetchone()[0]
        
        conn.close()
        
        stats['unified'] = {
            'total_memory_mappings': total_mappings,
            'weekly_memory_accesses': weekly_accesses,
            'system_health': self._calculate_system_health(basic_stats, advanced_stats, reminder_stats)
        }
        
        return stats
    
    def _calculate_system_health(self, basic_stats: Dict, advanced_stats: Dict, 
                               reminder_stats: Dict) -> str:
        """Calculate overall system health."""
        # Simple health calculation based on various metrics
        total_memories = basic_stats.get('total_memories', 0)
        total_relationships = advanced_stats.get('total_relationships', 0)
        avg_effectiveness = reminder_stats.get('average_effectiveness', 0.0)
        
        if total_memories == 0:
            return 'empty'
        elif total_memories < 10:
            return 'growing'
        elif avg_effectiveness > 0.7 and total_relationships > total_memories * 0.5:
            return 'excellent'
        elif avg_effectiveness > 0.5:
            return 'good'
        else:
            return 'needs_attention'
    
    def export_memory_data(self, format: str = 'json') -> str:
        """Export memory data in specified format."""
        if format.lower() == 'json':
            return self._export_to_json()
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def _export_to_json(self) -> str:
        """Export all memory data to JSON format."""
        export_data = {
            'export_timestamp': datetime.now().isoformat(),
            'basic_memories': [],
            'advanced_memories': [],
            'tasks': [],
            'feedback': [],
            'reminders': []
        }
        
        # Export basic memories
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM memories")
        basic_memories = cursor.fetchall()
        for memory in basic_memories:
            export_data['basic_memories'].append({
                'id': memory[0],
                'text': memory[1],
                'memory_type': memory[2],
                'priority': memory[3],
                'context': memory[4],
                'tags': memory[5],
                'created_at': memory[6],
                'updated_at': memory[7]
            })
        
        # Export tasks
        cursor.execute("SELECT * FROM tasks")
        tasks = cursor.fetchall()
        for task in tasks:
            export_data['tasks'].append({
                'id': task[0],
                'description': task[1],
                'status': task[2],
                'priority': task[3],
                'parent_id': task[4],
                'created_at': task[5],
                'completed_at': task[6]
            })
        
        conn.close()
        
        return json.dumps(export_data, indent=2)
    
    def import_memory_data(self, data: str, format: str = 'json') -> Dict[str, Any]:
        """Import memory data from specified format."""
        if format.lower() == 'json':
            return self._import_from_json(data)
        else:
            raise ValueError(f"Unsupported import format: {format}")
    
    def _import_from_json(self, data: str) -> Dict[str, Any]:
        """Import memory data from JSON format."""
        try:
            import_data = json.loads(data)
            result = {
                'imported_memories': 0,
                'imported_tasks': 0,
                'errors': []
            }
            
            # Import basic memories
            for memory_data in import_data.get('basic_memories', []):
                try:
                    self.basic_memory.add_memory(
                        memory_data['text'],
                        memory_data.get('memory_type', 'general'),
                        memory_data.get('priority', 0.5),
                        memory_data.get('context'),
                        memory_data.get('tags')
                    )
                    result['imported_memories'] += 1
                except Exception as e:
                    result['errors'].append(f"Memory import error: {str(e)}")
            
            # Import tasks
            for task_data in import_data.get('tasks', []):
                try:
                    self.basic_memory.add_task(
                        task_data['description'],
                        task_data.get('priority', 0),
                        task_data.get('parent_id')
                    )
                    result['imported_tasks'] += 1
                except Exception as e:
                    result['errors'].append(f"Task import error: {str(e)}")
            
            return result
            
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON data: {str(e)}") 