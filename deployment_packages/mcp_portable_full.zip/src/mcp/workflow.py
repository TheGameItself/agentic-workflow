#!/usr/bin/env python3
"""
Workflow Orchestration System
Manages project initialization, research, planning, development, and deployment phases.
"""

import os
import json
import sqlite3
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from enum import Enum

class WorkflowStatus(Enum):
    """Workflow status enumeration."""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    BLOCKED = "blocked"
    FAILED = "failed"

class WorkflowStep:
    """Base class for workflow steps."""
    
    def __init__(self, name: str, description: str, dependencies: Optional[List[str]] = None):
        self.name = name
        self.description = description
        self.dependencies = dependencies or []
        self.status = WorkflowStatus.NOT_STARTED
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None
        self.feedback = []
        self.artifacts = []
    
    def can_start(self, completed_steps: List[str]) -> bool:
        """Check if this step can start based on dependencies."""
        return all(dep in completed_steps for dep in self.dependencies)
    
    def start(self):
        """Start the workflow step."""
        self.status = WorkflowStatus.IN_PROGRESS
        self.started_at = datetime.now()
    
    def complete(self):
        """Complete the workflow step."""
        self.status = WorkflowStatus.COMPLETED
        self.completed_at = datetime.now()
    
    def add_feedback(self, feedback: str, impact: int = 0, principle: Optional[str] = None):
        """Add feedback to the step."""
        self.feedback.append({
            'text': feedback,
            'impact': impact,
            'principle': principle,
            'timestamp': datetime.now()
        })
    
    def add_artifact(self, artifact_type: str, artifact_data: Any):
        """Add an artifact to the step."""
        self.artifacts.append({
            'type': artifact_type,
            'data': artifact_data,
            'timestamp': datetime.now()
        })

class InitStep(WorkflowStep):
    """Project initialization step."""
    
    def __init__(self):
        super().__init__(
            name="init",
            description="Project initialization and setup",
            dependencies=[]
        )
        self.project_name = None
        self.project_path = None
        self.requirements = []
        self.questions = []
    
    def setup_project(self, name: str, path: str):
        """Setup the project with basic information."""
        self.project_name = name
        self.project_path = path
        self.add_artifact("project_info", {
            "name": name,
            "path": path,
            "created_at": datetime.now()
        })
    
    def add_requirement(self, requirement: str):
        """Add a project requirement."""
        self.requirements.append(requirement)
    
    def add_question(self, question: str):
        """Add a question for user/LLM alignment."""
        self.questions.append(question)

class ResearchStep(WorkflowStep):
    """Research and analysis step."""
    
    def __init__(self):
        super().__init__(
            name="research",
            description="Research project requirements, technologies, and best practices",
            dependencies=["init"]
        )
        self.research_topics = []
        self.findings = []
        self.sources = []
    
    def add_research_topic(self, topic: str, priority: float = 0.5):
        """Add a research topic."""
        self.research_topics.append({
            "topic": topic,
            "priority": priority,
            "status": "pending"
        })
    
    def add_finding(self, topic: str, finding: str, source: str = None):
        """Add a research finding."""
        self.findings.append({
            "topic": topic,
            "finding": finding,
            "source": source,
            "timestamp": datetime.now()
        })
        if source:
            self.add_source(source)
    
    def add_source(self, source: str):
        """Add a research source."""
        if source not in self.sources:
            self.sources.append(source)

class PlanningStep(WorkflowStep):
    """Project planning step."""
    
    def __init__(self):
        super().__init__(
            name="planning",
            description="Create comprehensive project plan and architecture",
            dependencies=["research"]
        )
        self.architecture = {}
        self.tasks = []
        self.milestones = []
        self.risks = []
    
    def set_architecture(self, arch: Dict[str, Any]):
        """Set the project architecture."""
        self.architecture = arch
        self.add_artifact("architecture", arch)
    
    def add_task(self, task: str, priority: int = 0, dependencies: List[str] = None):
        """Add a project task."""
        self.tasks.append({
            "description": task,
            "priority": priority,
            "dependencies": dependencies or [],
            "status": "pending"
        })
    
    def add_milestone(self, milestone: str, target_date: datetime):
        """Add a project milestone."""
        self.milestones.append({
            "description": milestone,
            "target_date": target_date,
            "status": "pending"
        })
    
    def add_risk(self, risk: str, impact: str, mitigation: str):
        """Add a project risk."""
        self.risks.append({
            "description": risk,
            "impact": impact,
            "mitigation": mitigation,
            "status": "open"
        })

class DevelopmentStep(WorkflowStep):
    """Development and implementation step."""
    
    def __init__(self):
        super().__init__(
            name="development",
            description="Implement the project according to the plan",
            dependencies=["planning"]
        )
        self.features = []
        self.bugs = []
        self.decisions = []
    
    def add_feature(self, feature: str, status: str = "planned"):
        """Add a feature to implement."""
        self.features.append({
            "description": feature,
            "status": status,
            "started_at": None,
            "completed_at": None
        })
    
    def add_bug(self, bug: str, severity: str = "medium"):
        """Add a bug to track."""
        self.bugs.append({
            "description": bug,
            "severity": severity,
            "status": "open",
            "reported_at": datetime.now()
        })
    
    def add_decision(self, decision: str, rationale: str):
        """Add a development decision."""
        self.decisions.append({
            "decision": decision,
            "rationale": rationale,
            "timestamp": datetime.now()
        })

class TestingStep(WorkflowStep):
    """Testing and quality assurance step."""
    
    def __init__(self):
        super().__init__(
            name="testing",
            description="Test the implementation and ensure quality",
            dependencies=["development"]
        )
        self.test_cases = []
        self.test_results = []
        self.issues = []
    
    def add_test_case(self, test_case: str, category: str = "functional"):
        """Add a test case."""
        self.test_cases.append({
            "description": test_case,
            "category": category,
            "status": "pending"
        })
    
    def add_test_result(self, test_case: str, result: str, notes: str = None):
        """Add a test result."""
        self.test_results.append({
            "test_case": test_case,
            "result": result,
            "notes": notes,
            "timestamp": datetime.now()
        })
    
    def add_issue(self, issue: str, severity: str = "medium"):
        """Add a testing issue."""
        self.issues.append({
            "description": issue,
            "severity": severity,
            "status": "open",
            "reported_at": datetime.now()
        })

class DeploymentStep(WorkflowStep):
    """Deployment and release step."""
    
    def __init__(self):
        super().__init__(
            name="deployment",
            description="Deploy the project to production",
            dependencies=["testing"]
        )
        self.environments = []
        self.deployments = []
        self.rollbacks = []
    
    def add_environment(self, env: str, config: Dict[str, Any]):
        """Add a deployment environment."""
        self.environments.append({
            "name": env,
            "config": config,
            "status": "configured"
        })
    
    def add_deployment(self, env: str, version: str, status: str = "pending"):
        """Add a deployment record."""
        self.deployments.append({
            "environment": env,
            "version": version,
            "status": status,
            "timestamp": datetime.now()
        })
    
    def add_rollback(self, env: str, from_version: str, to_version: str, reason: str):
        """Add a rollback record."""
        self.rollbacks.append({
            "environment": env,
            "from_version": from_version,
            "to_version": to_version,
            "reason": reason,
            "timestamp": datetime.now()
        })

class WorkflowManager:
    """Main workflow orchestration manager."""
    
    def __init__(self, db_path: str = None):
        """Initialize the workflow manager."""
        if db_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.join(current_dir, '..', '..')
            data_dir = os.path.join(project_root, 'data')
            os.makedirs(data_dir, exist_ok=True)
            db_path = os.path.join(data_dir, 'workflow.db')
        
        self.db_path = db_path
        self._init_database()
        
        # Initialize workflow steps
        self.steps = {
            'init': InitStep(),
            'research': ResearchStep(),
            'planning': PlanningStep(),
            'development': DevelopmentStep(),
            'testing': TestingStep(),
            'deployment': DeploymentStep()
        }
        
        self.current_step = None
        self.completed_steps = []
    
    def _init_database(self):
        """Initialize the workflow database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Workflow instances table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workflow_instances (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_name TEXT NOT NULL,
                project_path TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Workflow steps table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workflow_steps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id INTEGER,
                step_name TEXT NOT NULL,
                status TEXT DEFAULT 'not_started',
                started_at TIMESTAMP,
                completed_at TIMESTAMP,
                metadata TEXT,
                FOREIGN KEY (workflow_id) REFERENCES workflow_instances (id)
            )
        """)
        
        # Workflow feedback table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workflow_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                step_id INTEGER,
                feedback TEXT NOT NULL,
                impact INTEGER DEFAULT 0,
                principle TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (step_id) REFERENCES workflow_steps (id)
            )
        """)
        
        # Workflow artifacts table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS workflow_artifacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                step_id INTEGER,
                artifact_type TEXT NOT NULL,
                artifact_data TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (step_id) REFERENCES workflow_steps (id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def create_workflow(self, project_name: str, project_path: str) -> int:
        """Create a new workflow instance."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO workflow_instances (project_name, project_path)
            VALUES (?, ?)
        """, (project_name, project_path))
        
        workflow_id = cursor.lastrowid
        
        # Initialize steps for this workflow
        for step_name in self.steps.keys():
            cursor.execute("""
                INSERT INTO workflow_steps (workflow_id, step_name)
                VALUES (?, ?)
            """, (workflow_id, step_name))
        
        conn.commit()
        conn.close()
        
        return workflow_id
    
    def get_next_step(self) -> Optional[str]:
        """Get the next step that can be started."""
        for step_name, step in self.steps.items():
            if (step.status == WorkflowStatus.NOT_STARTED and 
                step.can_start(self.completed_steps)):
                return step_name
        return None
    
    def start_step(self, step_name: str) -> bool:
        """Start a workflow step."""
        if step_name not in self.steps:
            return False
        
        step = self.steps[step_name]
        if not step.can_start(self.completed_steps):
            return False
        
        step.start()
        self.current_step = step_name
        
        # Update database
        self._update_step_status(step_name, 'in_progress')
        
        return True
    
    def complete_step(self, step_name: str) -> bool:
        """Complete a workflow step."""
        if step_name not in self.steps:
            return False
        
        step = self.steps[step_name]
        if step.status != WorkflowStatus.IN_PROGRESS:
            return False
        
        step.complete()
        self.completed_steps.append(step_name)
        self.current_step = None
        
        # Update database
        self._update_step_status(step_name, 'completed')
        
        return True
    
    def add_step_feedback(self, step_name: str, feedback: str, impact: int = 0, principle: str = None):
        """Add feedback to a workflow step."""
        if step_name not in self.steps:
            return
        
        step = self.steps[step_name]
        step.add_feedback(feedback, impact, principle)
        
        # Update database
        self._add_step_feedback_db(step_name, feedback, impact, principle)
    
    def get_workflow_status(self) -> Dict[str, Any]:
        """Get the current workflow status."""
        status = {
            'current_step': self.current_step,
            'completed_steps': self.completed_steps,
            'total_steps': len(self.steps),
            'progress': len(self.completed_steps) / len(self.steps),
            'steps': {}
        }
        
        for step_name, step in self.steps.items():
            status['steps'][step_name] = {
                'name': step.name,
                'description': step.description,
                'status': step.status.value,
                'started_at': step.started_at.isoformat() if step.started_at else None,
                'completed_at': step.completed_at.isoformat() if step.completed_at else None,
                'feedback_count': len(step.feedback),
                'artifact_count': len(step.artifacts)
            }
        
        return status
    
    def get_step_details(self, step_name: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific step."""
        if step_name not in self.steps:
            return None
        
        step = self.steps[step_name]
        details = {
            'name': step.name,
            'description': step.description,
            'status': step.status.value,
            'dependencies': step.dependencies,
            'started_at': step.started_at.isoformat() if step.started_at else None,
            'completed_at': step.completed_at.isoformat() if step.completed_at else None,
            'feedback': step.feedback,
            'artifacts': step.artifacts
        }
        
        # Add step-specific details
        if isinstance(step, InitStep):
            details.update({
                'project_name': step.project_name,
                'project_path': step.project_path,
                'requirements': step.requirements,
                'questions': step.questions
            })
        elif isinstance(step, ResearchStep):
            details.update({
                'research_topics': step.research_topics,
                'findings': step.findings,
                'sources': step.sources
            })
        elif isinstance(step, PlanningStep):
            details.update({
                'architecture': step.architecture,
                'tasks': step.tasks,
                'milestones': step.milestones,
                'risks': step.risks
            })
        elif isinstance(step, DevelopmentStep):
            details.update({
                'features': step.features,
                'bugs': step.bugs,
                'decisions': step.decisions
            })
        elif isinstance(step, TestingStep):
            details.update({
                'test_cases': step.test_cases,
                'test_results': step.test_results,
                'issues': step.issues
            })
        elif isinstance(step, DeploymentStep):
            details.update({
                'environments': step.environments,
                'deployments': step.deployments,
                'rollbacks': step.rollbacks
            })
        
        return details
    
    def _update_step_status(self, step_name: str, status: str):
        """Update step status in database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE workflow_steps 
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE step_name = ?
        """, (status, step_name))
        
        conn.commit()
        conn.close()
    
    def _add_step_feedback_db(self, step_name: str, feedback: str, impact: int, principle: str):
        """Add step feedback to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get step ID
        cursor.execute("SELECT id FROM workflow_steps WHERE step_name = ?", (step_name,))
        step_id = cursor.fetchone()
        
        if step_id:
            cursor.execute("""
                INSERT INTO workflow_feedback (step_id, feedback, impact, principle)
                VALUES (?, ?, ?, ?)
            """, (step_id[0], feedback, impact, principle))
        
        conn.commit()
        conn.close()
    
    def complete_init_step(self) -> bool:
        """Complete the initialization step and allow progression to research."""
        # Allow completion regardless of current state for init step
        if 'init' in self.steps:
            step = self.steps['init']
            step.complete()
            self.completed_steps.append('init')
            self.current_step = None
            
            # Update database
            self._update_step_status('init', 'completed')
            return True
        return False
    
    def get_step_status(self, step_name: str) -> str:
        """Get the status of a specific step."""
        if step_name not in self.steps:
            return 'not_found'
        return self.steps[step_name].status.value
    
    def can_start_research(self) -> bool:
        """Check if research phase can be started."""
        # Allow research to start if init is completed OR if we have basic project info
        init_completed = self.get_step_status('init') == 'completed'
        # For now, allow research to start if init step exists
        return init_completed or 'init' in self.steps 