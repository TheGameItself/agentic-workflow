#!/usr/bin/env python3
"""
MCP Server Implementation
Core MCP server that provides unified interface for agentic development workflows.
"""

import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor

from .memory import MemoryManager
from .workflow import WorkflowManager
from .project_manager import ProjectManager
from .task_manager import TaskManager
from .context_manager import ContextManager
from .unified_memory import UnifiedMemoryManager
from .rag_system import RAGSystem
from .performance_monitor import PerformanceMonitor
from .reminder_engine import ReminderEngine

@dataclass
class MCPRequest:
    """MCP request structure."""
    method: str
    params: Dict[str, Any]
    id: Optional[str] = None
    jsonrpc: str = "2.0"

@dataclass
class MCPResponse:
    """MCP response structure."""
    result: Optional[Any] = None
    error: Optional[Dict[str, Any]] = None
    id: Optional[str] = None
    jsonrpc: str = "2.0"

class MCPServer:
    """
    Main MCP server implementation for agentic development workflows.
    
    This server provides a unified interface for all MCP interactions,
    managing projects, tasks, memory, and workflows in a portable,
    local-only environment.
    """
    
    def __init__(self, project_path: Optional[str] = None):
        """Initialize the MCP server."""
        self.project_path = project_path or os.getcwd()
        self.logger = self._setup_logging()
        
        # Initialize core components
        self.project_manager = ProjectManager(self.project_path)
        self.memory_manager = MemoryManager()
        self.workflow_manager = WorkflowManager()
        self.task_manager = TaskManager()
        self.context_manager = ContextManager()
        self.unified_memory = UnifiedMemoryManager()
        self.rag_system = RAGSystem()
        self.performance_monitor = PerformanceMonitor()
        self.reminder_engine = ReminderEngine()
        
        # Thread pool for async operations
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        # Server state
        self.is_running = False
        self.active_projects = {}
        self.feedback_model = self._initialize_feedback_model()
        
        self.logger.info("MCP Server initialized successfully")
    
    def _setup_logging(self) -> logging.Logger:
        """Setup logging configuration."""
        logger = logging.getLogger("mcp_server")
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _initialize_feedback_model(self) -> Dict[str, Any]:
        """Initialize the feedback model inspired by 'from zero' approach."""
        return {
            "learning_principles": {
                "experimentation": {"weight": 0.3, "success_rate": 0.0},
                "adaptation": {"weight": 0.25, "success_rate": 0.0},
                "optimization": {"weight": 0.25, "success_rate": 0.0},
                "validation": {"weight": 0.2, "success_rate": 0.0}
            },
            "feedback_history": [],
            "success_patterns": [],
            "failure_patterns": [],
            "adaptation_strategies": []
        }
    
    async def handle_request(self, request_data: str) -> str:
        """Handle incoming MCP request."""
        try:
            request = json.loads(request_data)
            mcp_request = MCPRequest(**request)
            
            # Route to appropriate handler
            result = await self._route_request(mcp_request)
            
            response = MCPResponse(
                result=result,
                id=mcp_request.id
            )
            
            return json.dumps(asdict(response))
            
        except Exception as e:
            self.logger.error(f"Error handling request: {e}")
            response = MCPResponse(
                error={
                    "code": -32603,
                    "message": "Internal error",
                    "data": str(e)
                },
                id=request.get("id") if "request" in locals() else None
            )
            return json.dumps(asdict(response))
    
    async def _route_request(self, request: MCPRequest) -> Any:
        """Route request to appropriate handler method."""
        method_handlers = {
            "initialize": self._handle_initialize,
            "create_project": self._handle_create_project,
            "get_project_status": self._handle_get_project_status,
            "update_configuration": self._handle_update_configuration,
            "start_workflow_step": self._handle_start_workflow_step,
            "create_task": self._handle_create_task,
            "update_task": self._handle_update_task,
            "get_tasks": self._handle_get_tasks,
            "add_memory": self._handle_add_memory,
            "search_memories": self._handle_search_memories,
            "get_context": self._handle_get_context,
            "rag_query": self._handle_rag_query,
            "bulk_action": self._handle_bulk_action,
            "get_feedback": self._handle_get_feedback,
            "provide_feedback": self._handle_provide_feedback,
            "get_suggestions": self._handle_get_suggestions,
            "export_project": self._handle_export_project,
            "import_project": self._handle_import_project,
            "get_performance": self._handle_get_performance,
            "optimize_system": self._handle_optimize_system
        }
        
        handler = method_handlers.get(request.method)
        if not handler:
            raise ValueError(f"Unknown method: {request.method}")
        
        return await handler(request.params)
    
    async def _handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle project initialization."""
        project_name = params.get("name")
        project_path = params.get("path", self.project_path)
        
        result = self.project_manager.init_project(project_name, project_path)
        
        # Initialize workflow
        workflow_id = self.workflow_manager.create_workflow(project_name, project_path)
        
        return {
            "status": "success",
            "project_info": result,
            "workflow_id": workflow_id,
            "next_steps": [
                "Review and fill in alignment questions",
                "Provide project requirements and constraints",
                "Start research phase",
                "Begin planning and architecture design"
            ],
            "available_commands": [
                "get_project_status",
                "update_configuration", 
                "start_workflow_step",
                "create_task",
                "get_suggestions"
            ]
        }
    
    async def _handle_create_project(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle project creation with enhanced setup."""
        project_name = params.get("name")
        project_path = params.get("path")
        idea_file = params.get("idea_file")
        
        # Create project
        result = self.project_manager.init_project(project_name, project_path)
        
        # Load idea if provided
        if idea_file and os.path.exists(idea_file):
            with open(idea_file, 'r') as f:
                idea_content = f.read()
            self.project_manager.answer_question("ALIGNMENT", "project_idea", idea_content)
        
        # Generate initial questions based on project type
        questions = self._generate_initial_questions(project_name, idea_file)
        
        return {
            "status": "success",
            "project_info": result,
            "initial_questions": questions,
            "next_steps": self._get_next_steps(result)
        }
    
    async def _handle_get_project_status(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get comprehensive project status."""
        project_info = self.project_manager.get_project_info()
        summary = self.project_manager.generate_project_summary()
        validation = self.project_manager.validate_configuration()
        workflow_status = self.workflow_manager.get_status()
        
        return {
            "project_info": project_info,
            "summary": summary,
            "validation": validation,
            "workflow_status": workflow_status,
            "completion_percentage": self._calculate_completion_percentage(project_info)
        }
    
    async def _handle_update_configuration(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Update project configuration."""
        section = params.get("section")
        key = params.get("key")
        value = params.get("value")
        
        success = self.project_manager.answer_question(section, key, value)
        
        if success:
            # Check if we can progress to next phase
            next_phase = self._check_phase_progression()
            return {
                "status": "success",
                "next_phase": next_phase,
                "suggestions": self._get_configuration_suggestions(section, key)
            }
        else:
            return {"status": "error", "message": "Failed to update configuration"}
    
    async def _handle_start_workflow_step(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Start a workflow step."""
        step_name = params.get("step")
        
        if step_name == "research":
            success = self.workflow_manager.start_step("research")
        elif step_name == "planning":
            success = self.workflow_manager.start_step("planning")
        elif step_name == "development":
            success = self.workflow_manager.start_step("development")
        else:
            return {"status": "error", "message": f"Unknown step: {step_name}"}
        
        if success:
            return {
                "status": "success",
                "step": step_name,
                "guidance": self._get_step_guidance(step_name)
            }
        else:
            return {"status": "error", "message": f"Cannot start {step_name} step"}
    
    async def _handle_create_task(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new task with enhanced metadata."""
        task_data = {
            "title": params.get("title"),
            "description": params.get("description"),
            "priority": params.get("priority", 5),
            "estimated_hours": params.get("estimated_hours", 0.0),
            "accuracy_critical": params.get("accuracy_critical", False),
            "tags": params.get("tags", "").split(",") if params.get("tags") else [],
            "parent_id": params.get("parent_id")
        }
        
        task_id = self.task_manager.create_task(**task_data)
        
        # Add to memory for future reference
        memory_text = f"Task created: {task_data['title']} - {task_data['description']}"
        self.memory_manager.add_memory(
            text=memory_text,
            memory_type="task_creation",
            priority=task_data["priority"] / 10.0,
            tags=task_data["tags"]
        )
        
        return {
            "status": "success",
            "task_id": task_id,
            "task_info": self.task_manager.get_task(task_id)
        }
    
    async def _handle_update_task(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Update task with progress tracking."""
        task_id = params.get("task_id")
        updates = params.get("updates", {})
        
        # Check if task is accuracy-critical
        task = self.task_manager.get_task(task_id)
        if task and task.get("accuracy_critical") and "status" in updates:
            # Require confirmation for accuracy-critical tasks
            if not params.get("confirmed"):
                return {
                    "status": "requires_confirmation",
                    "message": "This task is accuracy-critical. Please confirm the update.",
                    "task_info": task
                }
        
        success = self.task_manager.update_task(task_id, **updates)
        
        if success:
            # Update feedback model
            self._update_feedback_model("task_update", updates)
            
            return {"status": "success", "task_info": self.task_manager.get_task(task_id)}
        else:
            return {"status": "error", "message": "Failed to update task"}
    
    async def _handle_get_tasks(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get tasks with advanced filtering and tree structure."""
        filters = params.get("filters", {})
        include_tree = params.get("include_tree", False)
        
        tasks = self.task_manager.get_tasks(**filters)
        
        if include_tree:
            task_tree = self.task_manager.get_task_tree()
            return {
                "tasks": tasks,
                "tree": task_tree,
                "statistics": self.task_manager.get_task_statistics()
            }
        
        return {"tasks": tasks}
    
    async def _handle_add_memory(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Add memory with vector embedding."""
        memory_data = {
            "text": params.get("text"),
            "memory_type": params.get("type", "general"),
            "priority": params.get("priority", 0.5),
            "tags": params.get("tags", "").split(",") if params.get("tags") else [],
            "context": params.get("context")
        }
        
        memory_id = self.memory_manager.add_memory(**memory_data)
        
        # Add to RAG system
        self.rag_system.add_chunk(
            content=memory_data["text"],
            chunk_type="memory",
            source_id=memory_id,
            metadata={"type": memory_data["memory_type"], "tags": memory_data["tags"]}
        )
        
        return {"status": "success", "memory_id": memory_id}
    
    async def _handle_search_memories(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Search memories with vector similarity."""
        query = params.get("query")
        limit = params.get("limit", 10)
        memory_type = params.get("type")
        
        results = self.memory_manager.search_memories(
            query=query,
            limit=limit,
            memory_type=memory_type
        )
        
        return {"memories": results}
    
    async def _handle_get_context(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get optimized context for LLM."""
        context_types = params.get("types", "tasks,memories,progress").split(",")
        max_tokens = params.get("max_tokens", 1000)
        use_rag = params.get("use_rag", True)
        query = params.get("query")
        
        if use_rag and query:
            context = self.rag_system.query(
                query=query,
                chunk_types=context_types,
                max_tokens=max_tokens
            )
        else:
            context = self.context_manager.export_context(
                types=context_types,
                max_tokens=max_tokens
            )
        
        return {
            "context": context,
            "tokens_used": len(str(context)),
            "sources": context.get("sources", [])
        }
    
    async def _handle_rag_query(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Query the RAG system for intelligent retrieval."""
        query = params.get("query")
        chunk_types = params.get("types", "memory,task,code,document,feedback").split(",")
        max_tokens = params.get("max_tokens", 1000)
        
        results = self.rag_system.query(
            query=query,
            chunk_types=chunk_types,
            max_tokens=max_tokens
        )
        
        return {
            "results": results,
            "confidence": results.get("confidence", 0.0),
            "sources": results.get("sources", [])
        }
    
    async def _handle_bulk_action(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle bulk actions with accuracy limits."""
        action_type = params.get("action_type")
        items = params.get("items", [])
        accuracy_required = params.get("accuracy_required", False)
        
        if accuracy_required:
            # Check for accuracy-critical items
            critical_items = [item for item in items if item.get("accuracy_critical")]
            if critical_items and not params.get("confirmed"):
                return {
                    "status": "requires_confirmation",
                    "message": f"Found {len(critical_items)} accuracy-critical items",
                    "critical_items": critical_items
                }
        
        # Execute bulk action
        results = []
        for item in items:
            try:
                if action_type == "update_task_status":
                    result = self.task_manager.update_task(
                        item["task_id"], 
                        status=item["status"]
                    )
                elif action_type == "add_memory":
                    result = self.memory_manager.add_memory(**item)
                else:
                    result = {"status": "error", "message": f"Unknown action: {action_type}"}
                
                results.append(result)
            except Exception as e:
                results.append({"status": "error", "message": str(e)})
        
        return {
            "status": "success",
            "results": results,
            "summary": {
                "total": len(items),
                "successful": len([r for r in results if r.get("status") == "success"]),
                "failed": len([r for r in results if r.get("status") == "error"])
            }
        }
    
    async def _handle_get_feedback(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get feedback and learning insights."""
        feedback_type = params.get("type", "all")
        
        if feedback_type == "learning_principles":
            return {"feedback_model": self.feedback_model}
        elif feedback_type == "success_patterns":
            return {"patterns": self.feedback_model["success_patterns"]}
        elif feedback_type == "adaptation_strategies":
            return {"strategies": self.feedback_model["adaptation_strategies"]}
        else:
            return {"feedback_model": self.feedback_model}
    
    async def _handle_provide_feedback(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Provide feedback to improve the system."""
        feedback_data = {
            "action": params.get("action"),
            "outcome": params.get("outcome"),
            "success": params.get("success", True),
            "learning_principle": params.get("learning_principle"),
            "impact": params.get("impact", 0)
        }
        
        self._update_feedback_model("feedback", feedback_data)
        
        return {"status": "success", "message": "Feedback recorded"}
    
    async def _handle_get_suggestions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get intelligent suggestions based on context and history."""
        context = params.get("context", "")
        suggestion_type = params.get("type", "general")
        
        suggestions = []
        
        if suggestion_type == "next_steps":
            suggestions = self._get_next_step_suggestions(context)
        elif suggestion_type == "tasks":
            suggestions = self._get_task_suggestions(context)
        elif suggestion_type == "research":
            suggestions = self._get_research_suggestions(context)
        elif suggestion_type == "optimization":
            suggestions = self._get_optimization_suggestions(context)
        
        return {
            "suggestions": suggestions,
            "confidence": self._calculate_suggestion_confidence(suggestions),
            "reasoning": self._get_suggestion_reasoning(suggestions)
        }
    
    async def _handle_export_project(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Export project for portability."""
        export_path = params.get("path")
        include_data = params.get("include_data", True)
        
        export_data = {
            "project_info": self.project_manager.get_project_info(),
            "tasks": self.task_manager.get_all_tasks(),
            "memories": self.memory_manager.get_all_memories(),
            "workflow": self.workflow_manager.get_workflow_data(),
            "feedback_model": self.feedback_model
        }
        
        if export_path:
            with open(export_path, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
        
        return {
            "status": "success",
            "export_path": export_path,
            "export_size": len(str(export_data))
        }
    
    async def _handle_import_project(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Import project data."""
        import_path = params.get("path")
        
        if not os.path.exists(import_path):
            return {"status": "error", "message": "Import file not found"}
        
        with open(import_path, 'r') as f:
            import_data = json.load(f)
        
        # Import data into respective managers
        # Implementation depends on specific import requirements
        
        return {"status": "success", "message": "Project imported successfully"}
    
    async def _handle_get_performance(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Get system performance metrics."""
        return self.performance_monitor.get_summary()
    
    async def _handle_optimize_system(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize system performance."""
        optimization_type = params.get("type", "all")
        
        if optimization_type == "database":
            result = self.performance_monitor.optimize_database()
        elif optimization_type == "memory":
            result = self.memory_manager.optimize()
        elif optimization_type == "all":
            result = self.performance_monitor.optimize_all()
        else:
            result = {"status": "error", "message": f"Unknown optimization type: {optimization_type}"}
        
        return result
    
    def _generate_initial_questions(self, project_name: str, idea_file: Optional[str]) -> Dict[str, List[str]]:
        """Generate initial questions based on project type."""
        questions = {
            "ALIGNMENT": [
                "What is the primary goal of this project?",
                "Who are the target users?",
                "What are the key features needed?",
                "What are the technical constraints?",
                "What is the timeline for completion?"
            ],
            "RESEARCH": [
                "What technologies are unknown or need research?",
                "Are there competitors to analyze?",
                "What user research is needed?",
                "What are the technical risks?",
                "Are there compliance requirements?"
            ]
        }
        
        return questions
    
    def _get_next_steps(self, project_info: Dict[str, Any]) -> List[str]:
        """Get next steps based on project state."""
        return [
            "Review and fill in alignment questions",
            "Provide project requirements and constraints", 
            "Start research phase",
            "Begin planning and architecture design"
        ]
    
    def _calculate_completion_percentage(self, project_info: Dict[str, Any]) -> float:
        """Calculate project completion percentage."""
        # Implementation depends on project structure
        return 0.0
    
    def _check_phase_progression(self) -> Optional[str]:
        """Check if project can progress to next phase."""
        # Implementation depends on workflow state
        return None
    
    def _get_configuration_suggestions(self, section: str, key: str) -> List[str]:
        """Get suggestions based on configuration updates."""
        # Implementation for intelligent suggestions
        return []
    
    def _get_step_guidance(self, step_name: str) -> Dict[str, Any]:
        """Get guidance for workflow steps."""
        guidance = {
            "research": {
                "description": "Research phase focuses on understanding requirements and technologies",
                "tasks": ["Identify unknown technologies", "Analyze competitors", "Research user needs"],
                "deliverables": ["Research findings", "Technology recommendations", "Risk assessment"]
            },
            "planning": {
                "description": "Planning phase creates detailed project structure and architecture",
                "tasks": ["Design architecture", "Create task breakdown", "Define APIs"],
                "deliverables": ["Architecture diagram", "Task list", "API specification"]
            },
            "development": {
                "description": "Development phase implements the planned features",
                "tasks": ["Set up development environment", "Implement core features", "Write tests"],
                "deliverables": ["Working code", "Tests", "Documentation"]
            }
        }
        
        return guidance.get(step_name, {})
    
    def _update_feedback_model(self, action: str, data: Dict[str, Any]) -> None:
        """Update the feedback model with new information."""
        # Implementation for feedback model updates
        pass
    
    def _get_next_step_suggestions(self, context: str) -> List[Dict[str, Any]]:
        """Get suggestions for next steps."""
        # Implementation for intelligent suggestions
        return []
    
    def _get_task_suggestions(self, context: str) -> List[Dict[str, Any]]:
        """Get task suggestions."""
        return []
    
    def _get_research_suggestions(self, context: str) -> List[Dict[str, Any]]:
        """Get research suggestions."""
        return []
    
    def _get_optimization_suggestions(self, context: str) -> List[Dict[str, Any]]:
        """Get optimization suggestions."""
        return []
    
    def _calculate_suggestion_confidence(self, suggestions: List[Dict[str, Any]]) -> float:
        """Calculate confidence level for suggestions."""
        return 0.5
    
    def _get_suggestion_reasoning(self, suggestions: List[Dict[str, Any]]) -> str:
        """Get reasoning for suggestions."""
        return "Based on project context and historical patterns"
    
    def start(self, host: str = "localhost", port: int = 8000) -> None:
        """Start the MCP server."""
        self.is_running = True
        self.logger.info(f"MCP Server starting on {host}:{port}")
        
        # Start background tasks
        self._start_background_tasks()
        
        # In a real implementation, this would start an HTTP server
        # For now, we'll just log that the server is ready
        self.logger.info("MCP Server ready for requests")
    
    def stop(self) -> None:
        """Stop the MCP server."""
        self.is_running = False
        self.executor.shutdown(wait=True)
        self.logger.info("MCP Server stopped")
    
    def _start_background_tasks(self) -> None:
        """Start background tasks for monitoring and optimization."""
        # Start performance monitoring
        self.performance_monitor.start_monitoring()
        
        # Start reminder engine
        self.reminder_engine.start()
    
    def get_status(self) -> Dict[str, Any]:
        """Get server status."""
        return {
            "is_running": self.is_running,
            "active_projects": len(self.active_projects),
            "performance": self.performance_monitor.get_summary(),
            "memory_usage": self.memory_manager.get_statistics(),
            "task_count": self.task_manager.get_task_count()
        } 