#!/usr/bin/env python3
"""
Performance Monitoring and Optimization System
Tracks system performance and provides optimization recommendations.
"""

import time
import psutil
import os
import sqlite3
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import json
import threading
from collections import defaultdict, deque

class PerformanceMonitor:
    """System performance monitoring and optimization."""
    
    def __init__(self, db_path: str = None):
        self.db_path = db_path
        self.metrics_history = deque(maxlen=1000)  # Keep last 1000 measurements
        self.start_time = time.time()
        self.monitoring_active = False
        self.monitor_thread = None
        
        # Performance thresholds
        self.thresholds = {
            'memory_usage_mb': 500,  # 500MB memory usage warning
            'cpu_percent': 80,       # 80% CPU usage warning
            'query_time_ms': 100,    # 100ms query time warning
            'database_size_mb': 100, # 100MB database size warning
        }
    
    def start_monitoring(self, interval: float = 5.0):
        """Start continuous performance monitoring."""
        if self.monitoring_active:
            return
        
        self.monitoring_active = True
        self.monitor_thread = threading.Thread(
            target=self._monitor_loop,
            args=(interval,),
            daemon=True
        )
        self.monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop performance monitoring."""
        self.monitoring_active = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=1.0)
    
    def _monitor_loop(self, interval: float):
        """Main monitoring loop."""
        while self.monitoring_active:
            try:
                metrics = self.collect_metrics()
                self.metrics_history.append(metrics)
                time.sleep(interval)
            except Exception as e:
                print(f"Performance monitoring error: {e}")
                time.sleep(interval)
    
    def collect_metrics(self) -> Dict[str, Any]:
        """Collect current system metrics."""
        timestamp = datetime.now()
        
        # System metrics
        process = psutil.Process()
        memory_info = process.memory_info()
        
        metrics = {
            'timestamp': timestamp.isoformat(),
            'memory_usage_mb': memory_info.rss / (1024 * 1024),
            'cpu_percent': process.cpu_percent(),
            'thread_count': process.num_threads(),
            'open_files': len(process.open_files()),
            'connections': len(process.connections()),
        }
        
        # Database metrics
        if self.db_path and os.path.exists(self.db_path):
            db_metrics = self._collect_database_metrics()
            metrics.update(db_metrics)
        
        return metrics
    
    def _collect_database_metrics(self) -> Dict[str, Any]:
        """Collect database-specific metrics."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Database file size
            file_size = os.path.getsize(self.db_path) / (1024 * 1024)  # MB
            
            # Table sizes
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
            """)
            tables = cursor.fetchall()
            
            table_sizes = {}
            total_rows = 0
            
            for (table_name,) in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                table_sizes[table_name] = count
                total_rows += count
            
            # Database statistics
            cursor.execute("PRAGMA cache_size")
            cache_size = cursor.fetchone()[0]
            
            cursor.execute("PRAGMA page_count")
            page_count = cursor.fetchone()[0]
            
            cursor.execute("PRAGMA page_size")
            page_size = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'database_size_mb': file_size,
                'table_sizes': table_sizes,
                'total_rows': total_rows,
                'cache_size': cache_size,
                'page_count': page_count,
                'page_size': page_size,
                'database_health': self._assess_database_health(file_size, total_rows, cache_size)
            }
            
        except Exception as e:
            return {
                'database_error': str(e),
                'database_health': 'error'
            }
    
    def _assess_database_health(self, file_size: float, total_rows: int, cache_size: int) -> str:
        """Assess database health based on metrics."""
        if file_size > self.thresholds['database_size_mb']:
            return 'large'
        elif total_rows > 10000:
            return 'busy'
        elif cache_size < 1000:
            return 'cache_small'
        else:
            return 'healthy'
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get a summary of current performance metrics."""
        if not self.metrics_history:
            return {'error': 'No metrics collected yet'}
        
        latest = self.metrics_history[-1]
        
        # Calculate averages over last 10 measurements
        recent_metrics = list(self.metrics_history)[-10:]
        
        avg_memory = sum(m['memory_usage_mb'] for m in recent_metrics) / len(recent_metrics)
        avg_cpu = sum(m['cpu_percent'] for m in recent_metrics) / len(recent_metrics)
        
        # Identify issues
        issues = []
        if latest['memory_usage_mb'] > self.thresholds['memory_usage_mb']:
            issues.append(f"High memory usage: {latest['memory_usage_mb']:.1f}MB")
        
        if latest['cpu_percent'] > self.thresholds['cpu_percent']:
            issues.append(f"High CPU usage: {latest['cpu_percent']:.1f}%")
        
        if 'database_size_mb' in latest and latest['database_size_mb'] > self.thresholds['database_size_mb']:
            issues.append(f"Large database: {latest['database_size_mb']:.1f}MB")
        
        return {
            'current_metrics': latest,
            'average_memory_mb': avg_memory,
            'average_cpu_percent': avg_cpu,
            'uptime_seconds': time.time() - self.start_time,
            'issues': issues,
            'recommendations': self._generate_recommendations(latest, issues)
        }
    
    def _generate_recommendations(self, metrics: Dict[str, Any], issues: List[str]) -> List[str]:
        """Generate optimization recommendations."""
        recommendations = []
        
        if metrics['memory_usage_mb'] > self.thresholds['memory_usage_mb']:
            recommendations.append("Consider implementing memory cleanup for old data")
            recommendations.append("Review memory-intensive operations")
        
        if metrics['cpu_percent'] > self.thresholds['cpu_percent']:
            recommendations.append("Consider optimizing database queries")
            recommendations.append("Review background processes")
        
        if 'database_size_mb' in metrics and metrics['database_size_mb'] > self.thresholds['database_size_mb']:
            recommendations.append("Consider database cleanup and archiving")
            recommendations.append("Review data retention policies")
        
        if 'database_health' in metrics:
            if metrics['database_health'] == 'large':
                recommendations.append("Database is large - consider partitioning or archiving")
            elif metrics['database_health'] == 'cache_small':
                recommendations.append("Increase database cache size for better performance")
        
        if not recommendations:
            recommendations.append("System performance is within normal ranges")
        
        return recommendations
    
    def optimize_database(self) -> Dict[str, Any]:
        """Run database optimization commands."""
        if not self.db_path or not os.path.exists(self.db_path):
            return {'error': 'Database not found'}
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            start_time = time.time()
            
            # Run optimization commands
            cursor.execute("VACUUM")
            cursor.execute("ANALYZE")
            cursor.execute("REINDEX")
            
            optimization_time = time.time() - start_time
            conn.close()
            
            return {
                'success': True,
                'optimization_time_seconds': optimization_time,
                'message': 'Database optimization completed successfully'
            }
            
        except Exception as e:
            return {
                'error': str(e),
                'success': False
            }
    
    def get_metrics_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get historical metrics."""
        return list(self.metrics_history)[-limit:]
    
    def export_metrics(self, filepath: str):
        """Export metrics to JSON file."""
        data = {
            'export_time': datetime.now().isoformat(),
            'metrics': list(self.metrics_history),
            'summary': self.get_performance_summary()
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def clear_metrics(self):
        """Clear metrics history."""
        self.metrics_history.clear() 