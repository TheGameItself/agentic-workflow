#!/usr/bin/env python3
"""
Enhanced MCP CLI Interface
Command-line interface for the MCP Agentic Workflow Accelerator with advanced features.
"""

import click
import json
import os
from typing import List, Dict, Any, Optional
from datetime import datetime
from dataclasses import asdict
from pathlib import Path
from .memory import MemoryManager
from .workflow import WorkflowManager
from .project_manager import ProjectManager
from .task_manager import TaskManager
from .context_manager import ContextManager
from .unified_memory import UnifiedMemoryManager

def get_project_manager() -> ProjectManager:
    """Get a project manager instance with proper path detection."""
    # Try to find project config in current directory or parent directories
    current_dir = os.getcwd()
    manager = ProjectManager(current_dir)
    
    # Check if we're in a project directory
    config_file = manager.find_project_config()
    if config_file:
        # Update the manager to use the project directory
        project_dir = config_file.parent
        return ProjectManager(str(project_dir))
    
    return manager

def get_workflow_manager():
    """Get a WorkflowManager instance for the current project (scoped to data/workflow.db)."""
    manager = get_project_manager()
    project_info = manager.get_project_info()
    if not project_info or 'path' not in project_info:
        return WorkflowManager()  # fallback to default/global
    db_path = os.path.join(project_info['path'], 'data', 'workflow.db')
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    return WorkflowManager(db_path=db_path)

@click.group()
def cli():
    """MCP Agentic Workflow Accelerator CLI - Advanced Edition"""
    pass

# Project Management Commands
@cli.command()
@click.option('--name', prompt='Project name', help='Name of the new project')
@click.option('--path', default=None, help='Path for the project (defaults to current directory)')
def init_project(name, path):
    """Initialize a new project with MCP workflow."""
    manager = ProjectManager()
    result = manager.init_project(name, path)
    
    click.echo(f"[MCP] Project '{name}' initialized successfully!")
    click.echo(f"[MCP] Project path: {result['project_path']}")
    click.echo(f"[MCP] Configuration file: {result['config_file']}")
    click.echo("\n[MCP] Next steps:")
    for step in result['next_steps']:
        click.echo(f"  {step}")
    
    click.echo(f"\n[MCP] Use 'python mcp.py show-questions' to see alignment questions")
    click.echo(f"[MCP] Use 'python mcp.py answer-question' to provide answers")

@cli.command()
def show_questions():
    """Show all configuration questions for the current project."""
    manager = get_project_manager()
    questions = manager.get_questions()
    
    if not questions:
        click.echo("[MCP] No project configuration found. Run 'init-project' first.")
        click.echo("[MCP] Make sure you're in a project directory or run from the project root.")
        return
    
    click.echo("[MCP] Configuration Questions:")
    click.echo("=" * 50)
    
    for section, section_questions in questions.items():
        if section == 'PROJECT':
            continue  # Skip project metadata section
        click.echo(f"\n[{section.upper()}]")
        for key, value in section_questions.items():
            status = "✓" if value.strip() else "○"
            click.echo(f"  {status} {key}: {value or '(not answered)'}")

@cli.command()
@click.option('--section', prompt='Section', help='Configuration section')
@click.option('--key', prompt='Question key', help='Question key')
@click.option('--answer', prompt='Answer', help='Your answer')
def answer_question(section, key, answer):
    """Answer a configuration question."""
    manager = get_project_manager()
    success = manager.answer_question(section, key, answer)
    
    if success:
        click.echo(f"[MCP] Answer saved for {section}.{key}")
    else:
        click.echo(f"[MCP] Failed to save answer. Check section and key names.")
        click.echo("[MCP] Make sure you're in a project directory.")

@cli.command()
def project_status():
    """Show current project status and completion."""
    manager = get_project_manager()
    info = manager.get_project_info()
    summary = manager.generate_project_summary()
    validation = manager.validate_configuration()
    
    click.echo("[MCP] Project Status:")
    click.echo("=" * 30)
    click.echo(summary)
    
    if validation['errors']:
        click.echo("\n[MCP] Errors:")
        for error in validation['errors']:
            click.echo(f"  ❌ {error}")
    
    if validation['warnings']:
        click.echo("\n[MCP] Warnings:")
        for warning in validation['warnings']:
            click.echo(f"  ⚠️  {warning}")

# Workflow Commands
@cli.command()
def complete_init():
    """Complete the initialization phase and allow progression to research."""
    manager = get_project_manager()
    project_info = manager.get_project_info()
    if not project_info:
        click.echo("[MCP] No project found. Run 'init-project' first.")
        return
    
    workflow = get_workflow_manager()
    # Create workflow if it doesn't exist
    workflow_id = workflow.create_workflow(project_info['name'], project_info['path'])
    success = workflow.complete_init_step()
    if success:
        click.echo("[MCP] Initialization phase completed!")
        click.echo("[MCP] You can now start the research phase with 'start-research'")
    else:
        click.echo("[MCP] Initialization already completed or not in progress.")

@cli.command()
def start_research():
    """Start the research phase of the project."""
    manager = get_project_manager()
    project_info = manager.get_project_info()
    if not project_info:
        click.echo("[MCP] No project found. Run 'init-project' first.")
        return
    workflow = get_workflow_manager()
    if workflow.can_start_research():
        success = workflow.start_step('research')
        if success:
            click.echo("[MCP] Research phase started!")
            click.echo("[MCP] Use 'add-research-topic' to add research areas")
            click.echo("[MCP] Use 'add-finding' to record research findings")
        else:
            click.echo("[MCP] Failed to start research phase.")
    else:
        click.echo("[MCP] Cannot start research phase. Complete initialization first.")
        click.echo("[MCP] Use 'complete-init' to mark initialization as complete.")

@cli.command()
@click.option('--topic', prompt='Research topic', help='Topic to research')
@click.option('--priority', default=0.5, help='Priority (0.0-1.0)')
def add_research_topic(topic, priority):
    """Add a research topic."""
    workflow = get_workflow_manager()
    step = workflow.steps.get('research')
    if step and step.status.value == 'in_progress':
        step.add_research_topic(topic, priority)
        click.echo(f"[MCP] Research topic added: {topic}")
    else:
        click.echo("[MCP] Research phase not active. Start research first.")

@cli.command()
@click.option('--topic', prompt='Research topic', help='Topic this finding relates to')
@click.option('--finding', prompt='Finding', help='Research finding')
@click.option('--source', default=None, help='Source of the finding')
def add_finding(topic, finding, source):
    """Add a research finding."""
    workflow = get_workflow_manager()
    step = workflow.steps.get('research')
    if step and step.status.value == 'in_progress':
        step.add_finding(topic, finding, source)
        click.echo(f"[MCP] Finding added for topic: {topic}")
    else:
        click.echo("[MCP] Research phase not active. Start research first.")

@cli.command()
def start_planning():
    """Start the planning phase of the project."""
    workflow = get_workflow_manager()
    success = workflow.start_step('planning')
    if success:
        click.echo("[MCP] Planning phase started!")
        click.echo("[MCP] Use 'add-task' to add project tasks")
        click.echo("[MCP] Use 'set-architecture' to define system architecture")
    else:
        click.echo("[MCP] Cannot start planning phase. Complete research first.")

@cli.command()
@click.option('--description', prompt='Task description', help='Description of the task')
@click.option('--priority', default=0, help='Priority (0-10)')
def add_task(description, priority):
    """Add a project task."""
    workflow = get_workflow_manager()
    step = workflow.steps.get('planning')
    if step and step.status.value == 'in_progress':
        step.add_task(description, priority)
        click.echo(f"[MCP] Task added: {description}")
    else:
        click.echo("[MCP] Planning phase not active. Start planning first.")

@cli.command()
def workflow_status():
    """Show current workflow status."""
    workflow = get_workflow_manager()
    status = workflow.get_workflow_status()
    click.echo("[MCP] Workflow Status:")
    click.echo("=" * 30)
    click.echo(f"Progress: {status['progress']:.1%}")
    click.echo(f"Current Step: {status['current_step'] or 'None'}")
    click.echo(f"Completed Steps: {', '.join(status['completed_steps']) if status['completed_steps'] else 'None'}")
    click.echo("\n[MCP] Step Details:")
    for step_name, step_info in status['steps'].items():
        status_icon = "✅" if step_info['status'] == 'completed' else "⏳" if step_info['status'] == 'in_progress' else "○"
        click.echo(f"  {status_icon} {step_name}: {step_info['status']}")

# Memory Management Commands
@cli.command()
@click.option('--text', prompt='Memory text', help='Text content of the memory')
@click.option('--type', default='general', help='Memory type')
@click.option('--priority', default=0.5, help='Priority (0.0-1.0)')
@click.option('--context', default=None, help='Context for the memory')
@click.option('--tags', default=None, help='Comma-separated tags')
def add_memory(text, type, priority, context, tags):
    """Add a new memory."""
    manager = MemoryManager()
    
    tag_list = [tag.strip() for tag in tags.split(',')] if tags else None
    memory_id = manager.add_memory(text, type, priority, context, tag_list)
    
    click.echo(f"[MCP] Memory added with ID {memory_id}")
    click.echo(f"[MCP] Type: {type}")
    if tag_list:
        click.echo(f"[MCP] Tags: {', '.join(tag_list)}")

@cli.command()
@click.option('--query', prompt='Search query', help='Query to search for')
@click.option('--limit', default=10, help='Maximum number of results')
@click.option('--type', default=None, help='Filter by memory type')
def search_memories(query, limit, type):
    """Search memories by text content."""
    manager = MemoryManager()
    results = manager.search_memories(query, limit, type)
    
    if not results:
        click.echo("[MCP] No memories found matching your query.")
        return
    
    click.echo(f"[MCP] Found {len(results)} memories:")
    click.echo("=" * 50)
    
    for i, memory in enumerate(results, 1):
        click.echo(f"{i}. Memory {memory['id']} ({memory['memory_type']})")
        click.echo(f"   Text: {memory['text'][:100]}...")
        click.echo(f"   Priority: {memory['priority']}")
        click.echo(f"   Created: {memory['created_at']}")
        if memory['tags']:
            click.echo(f"   Tags: {', '.join(memory['tags'])}")
        click.echo()

@cli.command()
@click.option('--memory-id', prompt='Memory ID', type=int, help='ID of the memory')
def get_memory(memory_id):
    """Get a specific memory by ID."""
    manager = MemoryManager()
    memory = manager.get_memory(memory_id)
    
    if not memory:
        click.echo(f"[MCP] Memory {memory_id} not found.")
        return
    
    click.echo(f"[MCP] Memory {memory_id}:")
    click.echo("=" * 30)
    click.echo(f"Text: {memory['text']}")
    click.echo(f"Type: {memory['memory_type']}")
    click.echo(f"Priority: {memory['priority']}")
    click.echo(f"Context: {memory['context'] or 'None'}")
    if memory['tags']:
        click.echo(f"Tags: {', '.join(memory['tags'])}")
    click.echo(f"Created: {memory['created_at']}")
    click.echo(f"Updated: {memory['updated_at']}")

# Task Management Commands
@cli.command()
@click.option('--title', prompt='Task title', help='Title of the task')
@click.option('--description', default=None, help='Description of the task')
@click.option('--priority', default=5, type=int, help='Priority (1-10)')
@click.option('--parent-id', default=None, type=int, help='Parent task ID')
@click.option('--estimated-hours', default=0.0, type=float, help='Estimated hours')
@click.option('--accuracy-critical', is_flag=True, help='Mark as accuracy-critical')
@click.option('--due-date', default=None, help='Due date (YYYY-MM-DD)')
@click.option('--tags', default=None, help='Comma-separated tags')
def create_task(title, description, priority, parent_id, estimated_hours, 
                accuracy_critical, due_date, tags):
    """Create a new task with full metadata."""
    from datetime import datetime
    
    task_manager = TaskManager()
    
    # Parse due date
    parsed_due_date = None
    if due_date:
        try:
            parsed_due_date = datetime.strptime(due_date, '%Y-%m-%d')
        except ValueError:
            click.echo("[MCP] Invalid due date format. Use YYYY-MM-DD")
            return
    
    # Parse tags
    tag_list = [tag.strip() for tag in tags.split(',')] if tags else None
    
    task_id = task_manager.create_task(
        title=title,
        description=description,
        priority=priority,
        parent_id=parent_id,
        estimated_hours=estimated_hours,
        accuracy_critical=accuracy_critical,
        due_date=parsed_due_date,
        tags=tag_list
    )
    
    click.echo(f"[MCP] Task created with ID {task_id}")
    click.echo(f"[MCP] Title: {title}")
    click.echo(f"[MCP] Priority: {priority}")
    if accuracy_critical:
        click.echo("[MCP] ⚠️  Marked as accuracy-critical")

@cli.command()
@click.option('--status', default=None, help='Filter by status')
@click.option('--priority-min', default=None, type=int, help='Minimum priority')
@click.option('--include-completed', is_flag=True, help='Include completed tasks')
@click.option('--tree', is_flag=True, help='Show as tree structure')
def list_tasks(status, priority_min, include_completed, tree):
    """List tasks with advanced filtering."""
    task_manager = TaskManager()
    
    if tree:
        task_tree = task_manager.get_task_tree(include_completed=include_completed)
        _display_task_tree(task_tree['root_tasks'])
    else:
        tasks = task_manager.get_tasks(status)
        
        # Apply priority filter
        if priority_min:
            tasks = [t for t in tasks if t['priority'] >= priority_min]
        
        if not tasks:
            click.echo("[MCP] No tasks found.")
            return
        
        click.echo(f"[MCP] Found {len(tasks)} tasks:")
        click.echo("=" * 60)
        
        for i, task in enumerate(tasks, 1):
            status_icon = _get_status_icon(task['status'])
            critical_marker = " 🔴" if task.get('accuracy_critical') else ""
            click.echo(f"{i}. {status_icon} Task {task['id']}{critical_marker}")
            click.echo(f"   Title: {task['title']}")
            click.echo(f"   Status: {task['status']}")
            click.echo(f"   Priority: {task['priority']}")
            click.echo(f"   Created: {task['created_at']}")
            if task['completed_at']:
                click.echo(f"   Completed: {task['completed_at']}")
            click.echo()

@cli.command()
@click.option('--task-id', prompt='Task ID', type=int, help='ID of the task')
@click.option('--progress', default=None, type=float, help='Progress percentage (0-100)')
@click.option('--current-step', default=None, help='Current step description')
@click.option('--notes', default=None, help='Partial completion notes')
def update_task_progress(task_id, progress, current_step, notes):
    """Update task progress with partial completion support."""
    task_manager = TaskManager()
    
    if progress is None:
        progress = click.prompt('Progress percentage (0-100)', type=float)
    
    success = task_manager.update_task_progress(
        task_id, progress, current_step, notes
    )
    
    if success:
        click.echo(f"[MCP] Task {task_id} progress updated to {progress}%")
        if current_step:
            click.echo(f"[MCP] Current step: {current_step}")
    else:
        click.echo(f"[MCP] Failed to update task {task_id}")

@cli.command()
@click.option('--task-id', prompt='Task ID', type=int, help='ID of the task')
@click.option('--note', prompt='Note text', help='Note content')
@click.option('--line-number', default=None, type=int, help='Line number reference')
@click.option('--file-path', default=None, help='File path reference')
@click.option('--note-type', default='general', help='Type of note')
def add_task_note(task_id, note, line_number, file_path, note_type):
    """Add a note to a task with line number and file path support."""
    task_manager = TaskManager()
    
    note_id = task_manager.add_task_note(
        task_id, note, line_number, file_path, note_type
    )
    
    click.echo(f"[MCP] Note added with ID {note_id}")
    click.echo(f"[MCP] Task: {task_id}")
    if line_number:
        click.echo(f"[MCP] Line: {line_number}")
    if file_path:
        click.echo(f"[MCP] File: {file_path}")

@cli.command()
@click.option('--task-id', prompt='Task ID', type=int, help='ID of the task')
@click.option('--depends-on', prompt='Dependency task ID', type=int, help='Task this depends on')
@click.option('--dependency-type', default='blocks', help='Type of dependency')
def add_task_dependency(task_id, depends_on, dependency_type):
    """Add a dependency between tasks."""
    task_manager = TaskManager()
    
    dependency_id = task_manager.add_task_dependency(
        task_id, depends_on, dependency_type
    )
    
    click.echo(f"[MCP] Dependency added with ID {dependency_id}")
    click.echo(f"[MCP] Task {task_id} now depends on task {depends_on}")

@cli.command()
def show_blocked_tasks():
    """Show tasks that are blocked by incomplete dependencies."""
    task_manager = TaskManager()
    blocked_tasks = task_manager.get_blocked_tasks()
    
    if not blocked_tasks:
        click.echo("[MCP] No blocked tasks found.")
        return
    
    click.echo(f"[MCP] Found {len(blocked_tasks)} blocked tasks:")
    click.echo("=" * 50)
    
    for i, task in enumerate(blocked_tasks, 1):
        click.echo(f"{i}. Task {task['id']} (P{task['priority']})")
        click.echo(f"   Title: {task['title']}")
        click.echo(f"   Status: {task['status']}")
        click.echo(f"   Blocked by: {', '.join(task['blocking_tasks'])}")
        click.echo()

@cli.command()
def show_critical_tasks():
    """Show tasks marked as accuracy-critical."""
    task_manager = TaskManager()
    critical_tasks = task_manager.get_accuracy_critical_tasks()
    
    if not critical_tasks:
        click.echo("[MCP] No accuracy-critical tasks found.")
        return
    
    click.echo(f"[MCP] Found {len(critical_tasks)} accuracy-critical tasks:")
    click.echo("=" * 50)
    
    for i, task in enumerate(critical_tasks, 1):
        click.echo(f"{i}. 🔴 Task {task['id']} (P{task['priority']})")
        click.echo(f"   Title: {task['title']}")
        click.echo(f"   Status: {task['status']}")
        click.echo(f"   Estimated: {task['estimated_hours']} hours")
        click.echo()

# Context Management Commands
@cli.command()
@click.option('--types', default='tasks,memories,progress', help='Context types (comma-separated)')
@click.option('--max-tokens', default=1000, type=int, help='Maximum tokens')
@click.option('--save', is_flag=True, help='Save context pack for later')
@click.option('--format', default='text', help='Output format (text/json)')
@click.option('--use-rag', is_flag=True, help='Use RAG system for intelligent retrieval')
@click.option('--query', default=None, help='Query for RAG retrieval')
def export_context(types, max_tokens, save, format, use_rag, query):
    """Export minimal, relevant context for LLM consumption with RAG enhancement."""
    from .context_manager import ContextManager
    
    context_manager = ContextManager()
    context_types = [t.strip() for t in types.split(',')]
    
    if use_rag and query:
        # Use RAG system
        result = context_manager.export_context(
            context_types=context_types,
            max_tokens=max_tokens,
            format=format,
            use_rag=True,
            query=query
        )
        
        click.echo(f"[MCP] RAG Context Export:")
        click.echo(f"🎯 Confidence: {result.get('confidence', 0):.2f}")
        click.echo(f"📝 Tokens: {result.get('total_tokens', 0)}")
        click.echo(f"📊 Sources: {len(result.get('sources', []))}")
        click.echo()
        
        if format == 'json':
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(result.get('context', 'No context generated'))
    else:
        # Use traditional context generation
        result = context_manager.export_context(
            context_types=context_types,
            max_tokens=max_tokens,
            format=format,
            use_rag=False
        )
        
        click.echo(f"[MCP] Traditional Context Export:")
        click.echo(f"📝 Tokens: {result.get('total_tokens', 0)}")
        click.echo()
        
        if format == 'json':
            click.echo(json.dumps(result, indent=2))
        else:
            click.echo(result.get('context', 'No context generated'))
    
    if save:
        pack_id = context_manager.save_context_pack(
            name=f"Context Export {datetime.now().strftime('%Y%m%d_%H%M%S')}",
            context_data=result,
            description=f"Auto-saved context export with {len(context_types)} types"
        )
        click.echo(f"[MCP] Context pack saved with ID: {pack_id}")

@cli.command()
@click.option('--query', prompt='RAG query', help='Query for intelligent context retrieval')
@click.option('--types', default='memory,task,code,document,feedback', help='Chunk types to search')
@click.option('--max-tokens', default=1000, type=int, help='Maximum tokens')
@click.option('--project-id', default=None, help='Project ID to scope search')
@click.option('--format', default='text', help='Output format (text/json)')
def rag_query(query, types, max_tokens, project_id, format):
    """Query the RAG system for intelligent context retrieval."""
    from .rag_system import RAGSystem, RAGQuery
    
    rag_system = RAGSystem()
    chunk_types = [t.strip() for t in types.split(',')]
    
    # Create RAG query
    rag_query = RAGQuery(
        query=query,
        context={'project_id': project_id} if project_id else {},
        max_tokens=max_tokens,
        chunk_types=chunk_types,
        project_id=project_id,
        user_id=None
    )
    
    # Retrieve context
    result = rag_system.retrieve_context(rag_query)
    
    click.echo(f"[MCP] RAG Query Results:")
    click.echo(f"🎯 Confidence: {result.confidence:.2f}")
    click.echo(f"📝 Tokens: {result.total_tokens}")
    click.echo(f"📊 Chunks: {len(result.chunks)}")
    click.echo(f"📋 Summary: {result.summary}")
    click.echo()
    
    if format == 'json':
        # Convert to JSON-serializable format
        json_result = {
            'chunks': [
                {
                    'id': chunk.id,
                    'content': chunk.content,
                    'source_type': chunk.source_type,
                    'source_id': chunk.source_id,
                    'metadata': chunk.metadata
                }
                for chunk in result.chunks
            ],
            'total_tokens': result.total_tokens,
            'relevance_scores': result.relevance_scores,
            'sources': result.sources,
            'summary': result.summary,
            'confidence': result.confidence
        }
        click.echo(json.dumps(json_result, indent=2))
    else:
        # Text format
        for i, chunk in enumerate(result.chunks, 1):
            click.echo(f"--- Chunk {i}: {chunk.source_type.upper()} {chunk.source_id} ---")
            click.echo(f"Relevance: {result.relevance_scores[i-1]:.2f}")
            click.echo(f"Content: {chunk.content}")
            click.echo()

@cli.command()
@click.option('--content', prompt='Content to add', help='Content to add to RAG system')
@click.option('--type', prompt='Source type', help='Source type (memory/task/code/document/feedback)')
@click.option('--source-id', prompt='Source ID', type=int, help='Source ID')
@click.option('--project-id', default=None, help='Project ID')
@click.option('--metadata', default=None, help='JSON metadata')
def add_rag_chunk(content, type, source_id, project_id, metadata):
    """Add content to the RAG system for intelligent retrieval."""
    from .rag_system import RAGSystem
    
    rag_system = RAGSystem()
    
    # Parse metadata if provided
    metadata_dict = {}
    if metadata:
        try:
            metadata_dict = json.loads(metadata)
        except json.JSONDecodeError:
            click.echo("[MCP] Error: Invalid JSON metadata")
            return
    
    # Add chunk
    chunk_id = rag_system.add_chunk(
        content=content,
        source_type=type,
        source_id=source_id,
        project_id=project_id,
        metadata=metadata_dict
    )
    
    click.echo(f"[MCP] RAG chunk added with ID: {chunk_id}")

@cli.command()
@click.option('--query-id', prompt='Query ID', type=int, help='Query ID to provide feedback for')
@click.option('--score', prompt='Feedback score (1-5)', type=int, help='Feedback score')
@click.option('--feedback-text', default=None, help='Additional feedback text')
def rag_feedback(query_id, score, feedback_text):
    """Provide feedback on RAG query results to improve the system."""
    from .rag_system import RAGSystem
    
    rag_system = RAGSystem()
    
    if not 1 <= score <= 5:
        click.echo("[MCP] Error: Score must be between 1 and 5")
        return
    
    rag_system.add_feedback(query_id, score, feedback_text)
    click.echo(f"[MCP] Feedback added for query {query_id}")

@cli.command()
def rag_statistics():
    """Show RAG system statistics."""
    from .rag_system import RAGSystem
    
    rag_system = RAGSystem()
    stats = rag_system.get_statistics()
    
    click.echo("[MCP] RAG System Statistics:")
    click.echo("=" * 40)
    click.echo(f"📊 Total chunks: {stats['total_chunks']}")
    click.echo(f"🔍 Total queries: {stats['total_queries']}")
    click.echo(f"📝 Avg tokens per query: {stats['average_tokens_per_query']:.1f}")
    click.echo()
    
    click.echo("📋 Chunks by type:")
    for chunk_type, count in stats['chunks_by_type'].items():
        click.echo(f"  {chunk_type}: {count}")
    click.echo()
    
    if stats['top_patterns']:
        click.echo("🎯 Top relevance patterns:")
        for pattern, score, count in stats['top_patterns']:
            click.echo(f"  '{pattern}': {score:.2f} (used {count} times)")

@cli.command()
@click.option('--days', default=90, type=int, help='Days old to consider for cleanup')
def rag_cleanup(days):
    """Clean up old, rarely accessed RAG chunks."""
    from .rag_system import RAGSystem
    
    rag_system = RAGSystem()
    deleted_count = rag_system.cleanup_old_chunks(days)
    
    click.echo(f"[MCP] Cleaned up {deleted_count} old RAG chunks (older than {days} days)")

@cli.command()
@click.option('--pack-id', prompt='Pack ID', type=int, help='Context pack ID')
def get_context_pack(pack_id):
    """Retrieve a saved context pack."""
    from .context_manager import ContextManager
    
    context_manager = ContextManager()
    pack = context_manager.get_context_pack(pack_id)
    
    if pack:
        click.echo(f"[MCP] Context Pack: {pack['name']}")
        click.echo(f"Description: {pack['description'] or 'No description'}")
        click.echo(f"Type: {pack['context_type']}")
        click.echo(f"Project: {pack['project_id'] or 'Global'}")
        click.echo(f"Access count: {pack['access_count']}")
        click.echo(f"Created: {pack['created_at']}")
        click.echo()
        
        if isinstance(pack['context_data'], dict) and 'context' in pack['context_data']:
            click.echo(pack['context_data']['context'])
        else:
            click.echo(json.dumps(pack['context_data'], indent=2))
    else:
        click.echo(f"[MCP] Context pack {pack_id} not found")

@cli.command()
@click.option('--context-type', default=None, help='Filter by context type')
@click.option('--project-id', default=None, help='Filter by project ID')
def list_context_packs(context_type, project_id):
    """List available context packs."""
    from .context_manager import ContextManager
    
    context_manager = ContextManager()
    packs = context_manager.list_context_packs(context_type, project_id)
    
    if packs:
        click.echo(f"[MCP] Found {len(packs)} context packs:")
        click.echo("=" * 60)
        
        for pack in packs:
            click.echo(f"ID: {pack['id']}")
            click.echo(f"Name: {pack['name']}")
            click.echo(f"Type: {pack['context_type']}")
            click.echo(f"Project: {pack['project_id'] or 'Global'}")
            click.echo(f"Access count: {pack['access_count']}")
            click.echo(f"Created: {pack['created_at']}")
            click.echo("-" * 40)
    else:
        click.echo("[MCP] No context packs found")

@cli.command()
@click.option('--name', prompt='Template name', help='Template name')
@click.option('--description', default=None, help='Template description')
@click.option('--types', default='tasks,memories,progress', help='Context types')
@click.option('--max-tokens', default=1000, type=int, help='Maximum tokens')
def add_context_template(name, description, types, max_tokens):
    """Add a context template for reuse."""
    from .context_manager import ContextManager
    
    context_manager = ContextManager()
    context_types = [t.strip() for t in types.split(',')]
    
    template_data = {
        'context_types': context_types,
        'max_tokens': max_tokens,
        'created_at': datetime.now().isoformat()
    }
    
    template_id = context_manager.add_context_template(
        name=name,
        template_data=template_data,
        description=description,
        context_types=context_types,
        max_tokens=max_tokens
    )
    
    click.echo(f"[MCP] Context template added with ID: {template_id}")

@cli.command()
def list_context_templates():
    """List available context templates."""
    from .context_manager import ContextManager
    
    context_manager = ContextManager()
    templates = context_manager.list_context_templates()
    
    if templates:
        click.echo(f"[MCP] Found {len(templates)} context templates:")
        click.echo("=" * 60)
        
        for template in templates:
            click.echo(f"ID: {template['id']}")
            click.echo(f"Name: {template['name']}")
            click.echo(f"Description: {template['description'] or 'No description'}")
            click.echo(f"Types: {', '.join(template['context_types'])}")
            click.echo(f"Max tokens: {template['max_tokens']}")
            click.echo(f"Created: {template['created_at']}")
            click.echo("-" * 40)
    else:
        click.echo("[MCP] No context templates found")

# Regex Search Commands
@cli.command()
@click.option('--pattern', prompt='Regex pattern', help='Regular expression pattern to search for')
@click.option('--type', default='combined', help='Search type (file_system/database/memory/task/rag/combined)')
@click.option('--scope', default='current_project', help='Search scope (current_project/all_projects/specific_path/database_only)')
@click.option('--case-sensitive', is_flag=True, help='Case sensitive search')
@click.option('--multiline', is_flag=True, help='Multiline regex mode')
@click.option('--dot-all', is_flag=True, help='Dot matches all characters including newlines')
@click.option('--max-results', default=50, type=int, help='Maximum number of results')
@click.option('--context-lines', default=3, type=int, help='Number of context lines to show')
@click.option('--file-patterns', default=None, help='Comma-separated file patterns to include')
@click.option('--exclude-patterns', default=None, help='Comma-separated file patterns to exclude')
@click.option('--format', default='text', help='Output format (text/json/compact)')
@click.option('--project-path', default=None, help='Specific project path to search')
def regex_search(pattern, type, scope, case_sensitive, multiline, dot_all, 
                max_results, context_lines, file_patterns, exclude_patterns, 
                format, project_path):
    """Perform regex search across files and database content."""
    from .regex_search import RegexSearchEngine, SearchQuery, SearchType, SearchScope, RegexSearchFormatter
    
    # Parse search type
    try:
        search_type = SearchType(type)
    except ValueError:
        click.echo(f"[MCP] Error: Invalid search type '{type}'. Valid types: file_system, database, memory, task, rag, combined")
        return
    
    # Parse search scope
    try:
        search_scope = SearchScope(scope)
    except ValueError:
        click.echo(f"[MCP] Error: Invalid search scope '{scope}'. Valid scopes: current_project, all_projects, specific_path, database_only")
        return
    
    # Parse file patterns
    include_patterns = None
    if file_patterns:
        include_patterns = [p.strip() for p in file_patterns.split(',')]
    
    exclude_patterns_list = None
    if exclude_patterns:
        exclude_patterns_list = [p.strip() for p in exclude_patterns.split(',')]
    
    # Create search query
    query = SearchQuery(
        pattern=pattern,
        search_type=search_type,
        scope=search_scope,
        case_sensitive=case_sensitive,
        multiline=multiline,
        dot_all=dot_all,
        max_results=max_results,
        context_lines=context_lines,
        file_patterns=include_patterns,
        exclude_patterns=exclude_patterns_list,
        project_path=project_path
    )
    
    # Perform search
    search_engine = RegexSearchEngine(project_path=project_path)
    results = search_engine.search(query)
    
    # Format and display results
    formatted_output = RegexSearchFormatter.format_results(results, format, include_context=True)
    click.echo(formatted_output)
    
    # Show summary
    click.echo(f"\n[MCP] Search completed: {len(results)} results found")
    if len(results) >= max_results:
        click.echo(f"[MCP] Note: Results limited to {max_results} matches")

@cli.command()
@click.option('--pattern', prompt='Regex pattern', help='Regular expression pattern to search for')
@click.option('--file-patterns', default='*.py,*.js,*.ts,*.md,*.txt', help='Comma-separated file patterns to include')
@click.option('--exclude-patterns', default='__pycache__,*.pyc,*.git*', help='Comma-separated file patterns to exclude')
@click.option('--case-sensitive', is_flag=True, help='Case sensitive search')
@click.option('--max-results', default=20, type=int, help='Maximum number of results')
@click.option('--context-lines', default=2, type=int, help='Number of context lines to show')
def search_files(pattern, file_patterns, exclude_patterns, case_sensitive, max_results, context_lines):
    """Search for regex patterns in project files only."""
    from .regex_search import RegexSearchEngine, SearchQuery, SearchType, SearchScope, RegexSearchFormatter
    
    # Parse file patterns
    include_patterns = [p.strip() for p in file_patterns.split(',')]
    exclude_patterns_list = [p.strip() for p in exclude_patterns.split(',')]
    
    # Create search query
    query = SearchQuery(
        pattern=pattern,
        search_type=SearchType.FILE_SYSTEM,
        scope=SearchScope.CURRENT_PROJECT,
        case_sensitive=case_sensitive,
        max_results=max_results,
        context_lines=context_lines,
        file_patterns=include_patterns,
        exclude_patterns=exclude_patterns_list
    )
    
    # Perform search
    search_engine = RegexSearchEngine()
    results = search_engine.search(query)
    
    # Format and display results
    formatted_output = RegexSearchFormatter.format_results(results, 'text', include_context=True)
    click.echo(formatted_output)
    
    click.echo(f"\n[MCP] File search completed: {len(results)} results found")

@cli.command()
@click.option('--pattern', prompt='Regex pattern', help='Regular expression pattern to search for')
@click.option('--type', default='combined', help='Database search type (memory/task/rag/combined)')
@click.option('--case-sensitive', is_flag=True, help='Case sensitive search')
@click.option('--max-results', default=30, type=int, help='Maximum number of results')
def search_database(pattern, type, case_sensitive, max_results):
    """Search for regex patterns in database content only."""
    from .regex_search import RegexSearchEngine, SearchQuery, SearchType, SearchScope, RegexSearchFormatter
    
    # Parse search type
    try:
        search_type = SearchType(type)
    except ValueError:
        click.echo(f"[MCP] Error: Invalid search type '{type}'. Valid types: memory, task, rag, combined")
        return
    
    # Create search query
    query = SearchQuery(
        pattern=pattern,
        search_type=search_type,
        scope=SearchScope.DATABASE_ONLY,
        case_sensitive=case_sensitive,
        max_results=max_results
    )
    
    # Perform search
    search_engine = RegexSearchEngine()
    results = search_engine.search(query)
    
    # Format and display results
    formatted_output = RegexSearchFormatter.format_results(results, 'text', include_context=False)
    click.echo(formatted_output)
    
    click.echo(f"\n[MCP] Database search completed: {len(results)} results found")

@cli.command()
@click.option('--limit', default=10, type=int, help='Number of recent searches to show')
def search_history(limit):
    """Show recent regex search history."""
    from .regex_search import RegexSearchEngine
    
    search_engine = RegexSearchEngine()
    history = search_engine.get_search_history(limit)
    
    if history:
        click.echo(f"[MCP] Recent search history (last {len(history)} searches):")
        click.echo("=" * 60)
        
        for i, search in enumerate(reversed(history), 1):
            click.echo(f"{i}. Pattern: {search['pattern']}")
            click.echo(f"   Type: {search['search_type']}")
            click.echo(f"   Scope: {search['scope']}")
            click.echo(f"   Results: {search['result_count']}")
            click.echo(f"   Time: {search['timestamp']}")
            click.echo("-" * 40)
    else:
        click.echo("[MCP] No search history found")

@cli.command()
def search_cache_stats():
    """Show regex search cache statistics."""
    from .regex_search import RegexSearchEngine
    
    search_engine = RegexSearchEngine()
    stats = search_engine.get_cache_stats()
    
    click.echo("[MCP] Regex Search Cache Statistics:")
    click.echo("=" * 40)
    click.echo(f"📊 Cache entries: {stats['cache_size']}")
    click.echo(f"🔍 Cached results: {stats['total_cached_results']}")
    click.echo(f"📝 Search history: {stats['search_history_size']} entries")

@cli.command()
def clear_search_cache():
    """Clear the regex search cache."""
    from .regex_search import RegexSearchEngine
    
    search_engine = RegexSearchEngine()
    search_engine.clear_cache()
    
    click.echo("[MCP] Regex search cache cleared")

@cli.command()
def performance_summary():
    """Show current system performance summary."""
    try:
        from .performance_monitor import PerformanceMonitor
        
        # Get database path
        current_dir = os.getcwd()
        data_dir = os.path.join(current_dir, 'data')
        db_path = os.path.join(data_dir, 'unified_memory.db')
        
        monitor = PerformanceMonitor(db_path)
        summary = monitor.get_performance_summary()
        
        if 'error' in summary:
            click.echo(f"[MCP] Performance monitoring error: {summary['error']}")
            return
        
        click.echo("[MCP] Performance Summary")
        click.echo("=" * 50)
        
        metrics = summary['current_metrics']
        click.echo(f"💾 Memory Usage: {metrics['memory_usage_mb']:.1f}MB")
        click.echo(f"🖥️  CPU Usage: {metrics['cpu_percent']:.1f}%")
        click.echo(f"🧵 Threads: {metrics['thread_count']}")
        click.echo(f"📁 Open Files: {metrics['open_files']}")
        click.echo(f"🔗 Connections: {metrics['connections']}")
        
        if 'database_size_mb' in metrics:
            click.echo(f"🗄️  Database Size: {metrics['database_size_mb']:.1f}MB")
            click.echo(f"📊 Total Rows: {metrics.get('total_rows', 0)}")
            click.echo(f"🏥 Database Health: {metrics.get('database_health', 'unknown')}")
        
        click.echo(f"⏱️  Uptime: {summary['uptime_seconds']:.1f}s")
        
        if summary['issues']:
            click.echo("\n⚠️  Issues Detected:")
            for issue in summary['issues']:
                click.echo(f"  - {issue}")
        
        if summary['recommendations']:
            click.echo("\n💡 Recommendations:")
            for rec in summary['recommendations']:
                click.echo(f"  - {rec}")
                
    except ImportError:
        click.echo("[MCP] Performance monitoring not available (psutil not installed)")
    except Exception as e:
        click.echo(f"[MCP] Performance monitoring error: {e}")

@cli.command()
def optimize_database():
    """Run database optimization commands."""
    try:
        from .performance_monitor import PerformanceMonitor
        
        # Get database path
        current_dir = os.getcwd()
        data_dir = os.path.join(current_dir, 'data')
        db_path = os.path.join(data_dir, 'unified_memory.db')
        
        monitor = PerformanceMonitor(db_path)
        
        click.echo("[MCP] Starting database optimization...")
        result = monitor.optimize_database()
        
        if result['success']:
            click.echo(f"✅ {result['message']}")
            click.echo(f"⏱️  Optimization time: {result['optimization_time_seconds']:.2f}s")
        else:
            click.echo(f"❌ Optimization failed: {result['error']}")
            
    except ImportError:
        click.echo("[MCP] Performance monitoring not available (psutil not installed)")
    except Exception as e:
        click.echo(f"[MCP] Database optimization error: {e}")

@cli.command()
@click.option('--interval', default=5.0, type=float, help='Monitoring interval in seconds')
def start_monitoring(interval):
    """Start continuous performance monitoring."""
    try:
        from .performance_monitor import PerformanceMonitor
        
        # Get database path
        current_dir = os.getcwd()
        data_dir = os.path.join(current_dir, 'data')
        db_path = os.path.join(data_dir, 'unified_memory.db')
        
        monitor = PerformanceMonitor(db_path)
        monitor.start_monitoring(interval)
        
        click.echo(f"[MCP] Performance monitoring started (interval: {interval}s)")
        click.echo("[MCP] Use 'performance-summary' to view current metrics")
        click.echo("[MCP] Use 'stop-monitoring' to stop monitoring")
        
    except ImportError:
        click.echo("[MCP] Performance monitoring not available (psutil not installed)")
    except Exception as e:
        click.echo(f"[MCP] Failed to start monitoring: {e}")

@cli.command()
def stop_monitoring():
    """Stop performance monitoring."""
    try:
        from .performance_monitor import PerformanceMonitor
        
        # Get database path
        current_dir = os.getcwd()
        data_dir = os.path.join(current_dir, 'data')
        db_path = os.path.join(data_dir, 'unified_memory.db')
        
        monitor = PerformanceMonitor(db_path)
        monitor.stop_monitoring()
        
        click.echo("[MCP] Performance monitoring stopped")
        
    except ImportError:
        click.echo("[MCP] Performance monitoring not available (psutil not installed)")
    except Exception as e:
        click.echo(f"[MCP] Failed to stop monitoring: {e}")

@cli.command()
@click.option('--status', prompt='New status', help='New status for tasks')
@click.option('--task-ids', prompt='Task IDs (comma-separated)', help='Task IDs to update')
@click.option('--dry-run', is_flag=True, help='Show what would be changed without making changes')
@click.option('--force', is_flag=True, help='Force update even for accuracy-critical tasks')
def bulk_update_task_status(status, task_ids, dry_run, force):
    """Bulk update task status with safety checks."""
    from .task_manager import TaskManager
    
    task_manager = TaskManager()
    
    # Parse task IDs
    try:
        ids = [int(tid.strip()) for tid in task_ids.split(',')]
    except ValueError:
        click.echo("[MCP] Error: Invalid task ID format. Use comma-separated integers.")
        return
    
    # Check for accuracy-critical tasks
    critical_tasks = task_manager.get_accuracy_critical_tasks()
    critical_ids = [task['id'] for task in critical_tasks]
    affected_critical = [tid for tid in ids if tid in critical_ids]
    
    if affected_critical and not force:
        click.echo(f"[MCP] Warning: {len(affected_critical)} accuracy-critical tasks would be affected:")
        for tid in affected_critical:
            click.echo(f"  - Task ID: {tid}")
        click.echo("[MCP] Use --force to proceed or --dry-run to preview changes")
        return
    
    if dry_run:
        click.echo(f"[MCP] Dry run: Would update {len(ids)} tasks to status '{status}'")
        if affected_critical:
            click.echo(f"[MCP] Warning: {len(affected_critical)} accuracy-critical tasks would be affected")
        return
    
    # Perform bulk update
    success_count = 0
    for task_id in ids:
        try:
            # Update task progress to reflect status change
            if status == 'completed':
                task_manager.update_task_progress(task_id, 100.0, f"Completed via bulk update")
            elif status == 'in_progress':
                task_manager.update_task_progress(task_id, 25.0, f"Started via bulk update")
            elif status == 'pending':
                task_manager.update_task_progress(task_id, 0.0, f"Reset to pending via bulk update")
            success_count += 1
        except Exception as e:
            click.echo(f"[MCP] Error updating task {task_id}: {e}")
    
    click.echo(f"[MCP] Successfully updated {success_count}/{len(ids)} tasks to status '{status}'")

@cli.command()
@click.option('--task-id', prompt='Task ID', type=int, help='Task ID to add feedback for')
@click.option('--feedback', prompt='Feedback text', help='Feedback content')
@click.option('--impact', default=0, type=int, help='Impact score (-5 to 5)')
@click.option('--principle', default=None, help='Learning principle')
@click.option('--rating', default=3, type=int, help='Rating (1-5)')
def add_task_feedback(task_id, feedback, impact, principle, rating):
    """Add feedback to a completed task."""
    from .task_manager import TaskManager
    
    task_manager = TaskManager()
    
    # Validate task exists and is completed
    # Note: TaskManager doesn't have get_task method, so we'll proceed with feedback
    # Add feedback
    try:
        feedback_id = task_manager.add_task_feedback(
            task_id=task_id,
            feedback_text=feedback,
            impact_score=impact,
            principle=principle,
            feedback_type='general'
        )
        click.echo(f"[MCP] Feedback added with ID: {feedback_id}")
    except Exception as e:
        click.echo(f"[MCP] Error adding feedback: {e}")

@cli.command()
@click.option('--detailed', is_flag=True, help='Show detailed statistics')
def statistics(detailed):
    """Show comprehensive system statistics."""
    from .task_manager import TaskManager
    from .memory import MemoryManager
    from .context_manager import ContextManager
    from .unified_memory import UnifiedMemoryManager
    
    click.echo("[MCP] System Statistics")
    click.echo("=" * 50)
    
    # Task statistics
    task_manager = TaskManager()
    task_stats = task_manager.get_task_statistics()
    click.echo(f"📋 Tasks: {task_stats['total_tasks']} total")
    click.echo(f"  - Completed: {task_stats['completed_tasks']}")
    click.echo(f"  - Critical: {task_stats['critical_tasks']}")
    click.echo(f"  - Completion Rate: {task_stats['completion_rate']:.1f}%")
    
    # Memory statistics
    memory_manager = MemoryManager()
    memory_stats = memory_manager.get_statistics()
    click.echo(f"🧠 Memories: {memory_stats['total_memories']} total")
    click.echo(f"  - Types: {', '.join(memory_stats['memory_types'].keys())}")
    
    # Context statistics
    context_manager = ContextManager()
    context_stats = context_manager.get_statistics()
    click.echo(f"📦 Context Packs: {context_stats['context_packs']['total']} total")
    
    # Unified memory statistics
    unified_manager = UnifiedMemoryManager()
    unified_stats = unified_manager.get_comprehensive_statistics()
    click.echo(f"🔗 Unified System Health: {unified_stats['system_health']}")
    
    if detailed:
        click.echo("\n📊 Detailed Statistics:")
        click.echo(f"  - Database size: {unified_stats.get('database_size', 'Unknown')}")
        click.echo(f"  - Average task completion time: {unified_stats.get('avg_completion_time', 'Unknown')}")
        click.echo(f"  - Memory quality score: {unified_stats.get('avg_memory_quality', 'Unknown')}")

@cli.command()
def task_tree():
    """Display task hierarchy as a tree."""
    from .task_manager import TaskManager
    
    task_manager = TaskManager()
    
    # Show full task tree
    task_tree = task_manager.get_task_tree()
    if not task_tree or not task_tree.get('root_tasks'):
        click.echo("[MCP] No tasks found")
        return
    
    click.echo("[MCP] Complete Task Tree")
    click.echo("=" * 60)
    
    for root_task in task_tree['root_tasks']:
        _display_task_tree([root_task], 0)

# Helper Functions
def _get_status_icon(status):
    """Get status icon for display."""
    icons = {
        'pending': '⏳',
        'in_progress': '🔄',
        'partial': '📝',
        'completed': '✅',
        'blocked': '🚫',
        'cancelled': '❌'
    }
    return icons.get(status, '❓')

def _display_task_tree(tasks, level=0):
    """Display tasks in tree structure."""
    indent = "  " * level
    
    for task in tasks:
        status_icon = _get_status_icon(task['status'])
        critical_marker = " 🔴" if task.get('accuracy_critical') else ""
        
        click.echo(f"{indent}{status_icon} {task['title']} (ID: {task['id']}, P{task['priority']}){critical_marker}")
        
        if task['children']:
            _display_task_tree(task['children'], level + 1)

if __name__ == '__main__':
    cli() 