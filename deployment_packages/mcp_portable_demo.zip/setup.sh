#!/bin/bash
# MCP Agentic Workflow Accelerator - Portable Setup Script

echo "🚀 Setting up MCP Agentic Workflow Accelerator..."
echo "=================================================="

# Check Python version
python_version=$(python3 --version 2>&1)
echo "📦 Python version: $python_version"

# Install dependencies
echo "📦 Installing dependencies..."
pip3 install -r requirements.txt

# Test the system
echo "🧪 Testing system..."
python3 test_system.py

echo ""
echo "✅ Setup complete!"
echo ""
echo "📋 Available commands:"
echo "  python3 mcp_cli.py --help                    # Show all commands"
echo "  python3 mcp_cli.py create-task --help        # Create a new task"
echo "  python3 mcp_cli.py export-context --help     # Export context for LLM"
echo "  python3 mcp_cli.py statistics                # Show system statistics"
echo ""
echo "📖 Read README.md for detailed usage instructions"
